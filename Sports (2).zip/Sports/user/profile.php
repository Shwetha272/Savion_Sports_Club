<?php
$page_title = "My Profile";
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('../login.php');
}

// Check if user is student or coach
if (has_role('admin')) {
    redirect('../admin/dashboard.php');
}

// Get user information
$user = get_user($_SESSION['id']);

// Process profile update form
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $username = sanitize_input($_POST['username']);
    $email = sanitize_input($_POST['email']);
    $error = "";
    $success = "";
    
    // Additional fields based on role
    if (has_role('student')) {
        $usn = sanitize_input($_POST['usn']);
        $gender = sanitize_input($_POST['gender']);
        $branch = sanitize_input($_POST['branch']);
    } else if (has_role('coach')) {
        $usn = sanitize_input($_POST['college_id']); // College ID stored in USN field
        $gender = sanitize_input($_POST['gender']);
    }
    
    // Handle file upload
    $photo = $user['photo']; // Keep existing photo by default
    if(isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png");
        $filename = $_FILES["photo"]["name"];
        $filetype = $_FILES["photo"]["type"];
        $filesize = $_FILES["photo"]["size"];
    
        // Verify file extension
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        if(!array_key_exists($ext, $allowed)) {
            $error = "Error: Please select a valid file format.";
        }
    
        // Verify file size - 5MB maximum
        $maxsize = 5 * 1024 * 1024;
        if($filesize > $maxsize) {
            $error = "Error: File size is larger than the allowed limit (5MB).";
        }
    
        // Verify MIME type of the file
        if(in_array($filetype, $allowed) && empty($error)) {
            // Check whether file exists before uploading it
            $target_dir = "../uploads/";
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0777, true);
            }
            $new_filename = uniqid() . "." . $ext;
            $target_file = $target_dir . $new_filename;
            
            if(move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
                // Delete old photo if it exists
                if (!empty($user['photo']) && file_exists("../" . $user['photo'])) {
                    unlink("../" . $user['photo']);
                }
                $photo = "uploads/" . $new_filename;
            } else {
                $error = "Error: There was a problem uploading your file. Please try again.";
            }
        }
    }
    
    // Validate input
    if (empty($username) || empty($email)) {
        $error = "Please fill all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {
        // Check if username already exists (except current user)
        $sql = "SELECT id FROM users WHERE username = ? AND id != ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "si", $username, $_SESSION['id']);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        
        if (mysqli_stmt_num_rows($stmt) > 0) {
            $error = "Username already exists. Please choose another one.";
        } else {
            // Check if email already exists (except current user)
            $sql = "SELECT id FROM users WHERE email = ? AND id != ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "si", $email, $_SESSION['id']);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            
            if (mysqli_stmt_num_rows($stmt) > 0) {
                $error = "Email already exists. Please use another email.";
            } else {
                // Update user profile
                if (has_role('student')) {
                    $sql = "UPDATE users SET username = ?, email = ?, usn = ?, gender = ?, branch = ?, photo = ? WHERE id = ?";
                    $stmt = mysqli_prepare($conn, $sql);
                    mysqli_stmt_bind_param($stmt, "ssssssi", $username, $email, $usn, $gender, $branch, $photo, $_SESSION['id']);
                } else {
                    $sql = "UPDATE users SET username = ?, email = ?, usn = ?, gender = ?, photo = ? WHERE id = ?";
                    $stmt = mysqli_prepare($conn, $sql);
                    mysqli_stmt_bind_param($stmt, "sssssi", $username, $email, $usn, $gender, $photo, $_SESSION['id']);
                }
                
                if (mysqli_stmt_execute($stmt)) {
                    $success = "Profile updated successfully!";
                    $_SESSION['username'] = $username; // Update session username
                    $user = get_user($_SESSION['id']); // Refresh user data
                } else {
                    $error = "Something went wrong. Please try again later.";
                }
            }
        }
    }
}

// Process password change form
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    $error_pwd = "";
    $success_pwd = "";
    
    // Validate input
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error_pwd = "Please fill all password fields.";
    } elseif ($new_password != $confirm_password) {
        $error_pwd = "New passwords do not match.";
    } elseif (strlen($new_password) < 6) {
        $error_pwd = "Password must be at least 6 characters long.";
    } else {
        // Verify current password
        if (password_verify($current_password, $user['password'])) {
            // Hash the new password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            // Update password
            $sql = "UPDATE users SET password = ? WHERE id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "si", $hashed_password, $_SESSION['id']);
            
            if (mysqli_stmt_execute($stmt)) {
                $success_pwd = "Password changed successfully!";
            } else {
                $error_pwd = "Something went wrong. Please try again later.";
            }
        } else {
            $error_pwd = "Current password is incorrect.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            position: relative;
            background-color: transparent !important;
        }
        
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('../images/sgbit.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            opacity: 0.2;
            z-index: -1;
        }
    </style>
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include_once 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">My Profile</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 text-center mb-4">
                                <?php if (!empty($user['photo']) && file_exists("../" . $user['photo'])): ?>
                                    <img src="<?php echo "../" . $user['photo']; ?>" alt="Profile Photo" class="img-fluid rounded-circle profile-img mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                                <?php else: ?>
                                    <img src="../assets/img/default-profile.png" alt="Default Profile" class="img-fluid rounded-circle profile-img mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                                <?php endif; ?>
                                <h5><?php echo htmlspecialchars($user['username']); ?></h5>
                                <p class="badge bg-primary"><?php echo ucfirst($user['role']); ?></p>
                            </div>
                            <div class="col-md-8">
                                <?php if (isset($error) && !empty($error)): ?>
                                    <div class="alert alert-danger"><?php echo $error; ?></div>
                                <?php endif; ?>
                                
                                <?php if (isset($success) && !empty($success)): ?>
                                    <div class="alert alert-success"><?php echo $success; ?></div>
                                <?php endif; ?>
                                
                                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                                    <div class="mb-3">
                                        <label for="username" class="form-label">Username</label>
                                        <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                                    </div>
                                    
                                    <?php if (has_role('student')): ?>
                                    <div class="mb-3">
                                        <label for="usn" class="form-label">USN (University Serial Number)</label>
                                        <input type="text" class="form-control" id="usn" name="usn" value="<?php echo htmlspecialchars($user['usn']); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="gender" class="form-label">Gender</label>
                                        <select class="form-select" id="gender" name="gender" required>
                                            <option value="">Select Gender</option>
                                            <option value="male" <?php echo ($user['gender'] == 'male') ? 'selected' : ''; ?>>Male</option>
                                            <option value="female" <?php echo ($user['gender'] == 'female') ? 'selected' : ''; ?>>Female</option>
                                            <option value="other" <?php echo ($user['gender'] == 'other') ? 'selected' : ''; ?>>Other</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="branch" class="form-label">Branch</label>
                                        <select class="form-select" id="branch" name="branch">
                                            <option value="">Select Branch</option>
                                            <option value="Computer Science" <?php echo ($user['branch'] == 'Computer Science') ? 'selected' : ''; ?>>Computer Science</option>
                                            <option value="Information Technology" <?php echo ($user['branch'] == 'Information Technology') ? 'selected' : ''; ?>>Information Technology</option>
                                            <option value="Electronics" <?php echo ($user['branch'] == 'Electronics') ? 'selected' : ''; ?>>Electronics</option>
                                            <option value="Mechanical" <?php echo ($user['branch'] == 'Mechanical') ? 'selected' : ''; ?>>Mechanical</option>
                                            <option value="Civil" <?php echo ($user['branch'] == 'Civil') ? 'selected' : ''; ?>>Civil</option>
                                            <option value="Other" <?php echo ($user['branch'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                                        </select>
                                    </div>
                                    <?php elseif (has_role('coach')): ?>
                                    <div class="mb-3">
                                        <label for="college_id" class="form-label">College ID Number</label>
                                        <input type="text" class="form-control" id="college_id" name="college_id" value="<?php echo htmlspecialchars($user['usn']); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="gender" class="form-label">Gender</label>
                                        <select class="form-select" id="gender" name="gender" required>
                                            <option value="">Select Gender</option>
                                            <option value="male" <?php echo ($user['gender'] == 'male') ? 'selected' : ''; ?>>Male</option>
                                            <option value="female" <?php echo ($user['gender'] == 'female') ? 'selected' : ''; ?>>Female</option>
                                            <option value="other" <?php echo ($user['gender'] == 'other') ? 'selected' : ''; ?>>Other</option>
                                        </select>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <div class="mb-3">
                                        <label for="photo" class="form-label">Profile Photo</label>
                                        <input type="file" class="form-control" id="photo" name="photo" accept="image/*">
                                        <small class="text-muted">Upload a photo (JPG, PNG, GIF). Max size: 5MB</small>
                                    </div>
                                    
                                    <div class="d-grid gap-2">
                                        <button type="submit" name="update_profile" class="btn btn-primary">Update Profile</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Change Password</h5>
                    </div>
                    <div class="card-body">
                        <?php if (isset($error_pwd) && !empty($error_pwd)): ?>
                            <div class="alert alert-danger"><?php echo $error_pwd; ?></div>
                        <?php endif; ?>
                        
                        <?php if (isset($success_pwd) && !empty($success_pwd)): ?>
                            <div class="alert alert-success"><?php echo $success_pwd; ?></div>
                        <?php endif; ?>
                        
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                            <div class="mb-3">
                                <label for="current_password" class="form-label">Current Password</label>
                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                            </div>
                            <div class="mb-3">
                                <label for="new_password" class="form-label">New Password</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                                <small class="text-muted">Password must be at least 6 characters long.</small>
                            </div>
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">Confirm New Password</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>
                            <div class="d-grid gap-2">
                                <button type="submit" name="change_password" class="btn btn-danger">Change Password</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html>