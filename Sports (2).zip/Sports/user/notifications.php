<?php
$page_title = "Notifications";
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('../login.php');
}

// Check if user is student or coach
if (has_role('admin')) {
    redirect('../admin/dashboard.php');
}

$user_id = $_SESSION['id'];

// Mark all notifications as read if requested
if (isset($_GET['mark_all_read'])) {
    $sql = "UPDATE notifications SET is_read = 1 WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    
    redirect('notifications.php');
}

// Mark a specific notification as read
if (isset($_GET['mark_read']) && !empty($_GET['mark_read'])) {
    $notification_id = sanitize_input($_GET['mark_read']);
    
    $sql = "UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $notification_id, $user_id);
    mysqli_stmt_execute($stmt);
    
    // Redirect to the target URL if provided
    if (isset($_GET['redirect']) && !empty($_GET['redirect'])) {
        redirect(urldecode($_GET['redirect']));
    } else {
        redirect('notifications.php');
    }
}

// Get all notifications for the user
$sql = "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$notifications = [];
while ($row = mysqli_fetch_assoc($result)) {
    $notifications[] = $row;
}

// Count unread notifications
$unread_count = 0;
foreach ($notifications as $notification) {
    if ($notification['is_read'] == 0) {
        $unread_count++;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include_once 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">
                            Notifications
                            <?php if ($unread_count > 0): ?>
                                <span class="badge bg-danger ms-2"><?php echo $unread_count; ?> new</span>
                            <?php endif; ?>
                        </h5>
                        <?php if (!empty($notifications)): ?>
                            <a href="notifications.php?mark_all_read=1" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-check-double me-2"></i> Mark All as Read
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <?php if (empty($notifications)): ?>
                            <div class="alert alert-info">
                                <i class="fas fa-bell-slash me-2"></i> You don't have any notifications yet.
                            </div>
                        <?php else: ?>
                            <div class="list-group">
                                <?php foreach ($notifications as $notification): ?>
                                    <a href="notifications.php?mark_read=<?php echo $notification['id']; ?><?php echo !empty($notification['link']) ? '&redirect=' . urlencode($notification['link']) : ''; ?>" 
                                       class="list-group-item list-group-item-action <?php echo ($notification['is_read'] == 0) ? 'list-group-item-light' : ''; ?>">
                                        <div class="d-flex w-100 justify-content-between">
                                            <h6 class="mb-1">
                                                <?php if ($notification['is_read'] == 0): ?>
                                                    <span class="badge bg-primary me-2">New</span>
                                                <?php endif; ?>
                                                <?php 
                                                $icon = 'info-circle';
                                                switch ($notification['type']) {
                                                    case 'request_update':
                                                        $icon = 'clipboard-check';
                                                        break;
                                                    case 'event_update':
                                                        $icon = 'calendar-alt';
                                                        break;
                                                    case 'booking_update':
                                                        $icon = 'calendar-check';
                                                        break;
                                                    case 'system':
                                                        $icon = 'cog';
                                                        break;
                                                }
                                                ?>
                                                <i class="fas fa-<?php echo $icon; ?> me-2"></i>
                                                <?php echo htmlspecialchars($notification['message']); ?>
                                            </h6>
                                            <small><?php echo time_elapsed_string($notification['created_at']); ?></small>
                                        </div>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>