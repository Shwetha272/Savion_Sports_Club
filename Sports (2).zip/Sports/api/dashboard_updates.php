<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Initialize response array
$response = [];

// Get user ID from session
$user_id = $_SESSION['id'];

// Get available equipment count - this is needed for both roles
$response['available_equipment'] = count_available_equipment();

// Get all available equipment for the equipment request page
$response['equipment_list'] = get_available_equipment_list();

if (has_role('student')) {
    // Get pending requests count for student
    $response['pending_requests'] = count_user_pending_requests($user_id);
    
    // Get approved requests count for student
    $response['approved_requests'] = count_user_approved_requests($user_id);
    
    // Get user equipment requests (limited to 5 most recent)
    $response['requests'] = get_user_requests($user_id, 5);
    
    // Get user notifications (limited to 3 most recent)
    $response['notifications'] = get_user_notifications($user_id, 3);
} elseif (has_role('coach')) {
    // For coach dashboard, directly query the database for accurate counts
    global $conn;
    
    // Get pending requests count for coach's students
    $stmt = $conn->prepare("SELECT COUNT(*) FROM equipment_requests er 
                           JOIN users u ON er.user_id = u.id 
                           WHERE u.coach_id = ? AND er.status = 'pending'");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($pending_count);
    $stmt->fetch();
    $stmt->close();
    $response['pending_requests'] = $pending_count;
    
    // Get approved requests count for coach's students
    $stmt = $conn->prepare("SELECT COUNT(*) FROM equipment_requests er 
                           JOIN users u ON er.user_id = u.id 
                           WHERE u.coach_id = ? AND er.status = 'approved'");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($approved_count);
    $stmt->fetch();
    $stmt->close();
    $response['approved_requests'] = $approved_count;
    
    // Get overdue equipment count for coach's students
    $stmt = $conn->prepare("SELECT COUNT(*) FROM equipment_requests er 
                           JOIN users u ON er.user_id = u.id 
                           WHERE u.coach_id = ? AND er.status = 'overdue'");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($overdue_count);
    $stmt->fetch();
    $stmt->close();
    $response['overdue_equipment'] = $overdue_count;
    
    // Get coach's students count
    $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE coach_id = ? AND role = 'student'");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($students_count);
    $stmt->fetch();
    $stmt->close();
    $response['students_count'] = $students_count;
    
    // Get recent requests for coach's students
    $stmt = $conn->prepare("SELECT er.*, e.name as equipment_name, u.username 
                           FROM equipment_requests er 
                           JOIN equipment e ON er.equipment_id = e.id 
                           JOIN users u ON er.user_id = u.id 
                           WHERE u.coach_id = ? 
                           ORDER BY er.request_date DESC LIMIT 5");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $requests = [];
    while ($row = $result->fetch_assoc()) {
        $requests[] = $row;
    }
    $stmt->close();
    $response['requests'] = $requests;
    
    // Get coach notifications
    $response['notifications'] = get_user_notifications($user_id, 3);
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
exit;

// Function to get available equipment list
function get_available_equipment_list() {
    global $conn;
    
    $stmt = $conn->prepare("SELECT id, name, description, quantity, category 
                           FROM equipment 
                           WHERE quantity > 0 AND status = 'available'
                           ORDER BY name ASC");
    $stmt->execute();
    $result = $stmt->get_result();
    $equipment = [];
    while ($row = $result->fetch_assoc()) {
        $equipment[] = $row;
    }
    $stmt->close();
    
    return $equipment;
}
?>