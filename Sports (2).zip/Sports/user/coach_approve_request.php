<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('../login.php');
}

// Check if user is coach
if (!has_role('coach')) {
    set_message('error', 'You do not have permission to access this page.');
    redirect('dashboard.php');
}

// Check if request ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    set_message('error', 'Invalid request ID.');
    redirect('coach_requests.php');
}

$request_id = sanitize_input($_GET['id']);

// Get request details
$request = get_request_by_id($request_id);

// Check if request exists and is pending
if (!$request || $request['status'] != 'pending') {
    set_message('error', 'Invalid request or request is not pending.');
    redirect('coach_requests.php');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $expected_return_date = sanitize_input($_POST['expected_return_date']);
    $notes = sanitize_input($_POST['notes']);
    
    // Validate return date
    if (empty($expected_return_date) || strtotime($expected_return_date) <= time()) {
        set_message('error', 'Please select a valid future return date.');
    } else {
        // Update request status to approved
        $sql = "UPDATE equipment_requests SET 
                status = 'approved', 
                expected_return_date = ?, 
                approval_notes = ?,
                approved_by = ?,
                approval_date = NOW()
                WHERE id = ?";
        
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssii", $expected_return_date, $notes, $_SESSION['id'], $request_id);
        
        if (mysqli_stmt_execute($stmt)) {
            // Update equipment available quantity
            $equipment = get_equipment_by_id($request['equipment_id']);
            $new_available = $equipment['available'] - $request['quantity'];
            
            $sql = "UPDATE equipment SET available = ? WHERE id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ii", $new_available, $request['equipment_id']);
            mysqli_stmt_execute($stmt);
            
            // Create notification for the user
            $message = "Your request for " . $request['equipment_name'] . " has been approved.";
            $link = "request_details.php?id=" . $request_id;
            create_notification($request['user_id'], 'request_update', $message, $link);
            
            set_message('success', 'Request has been approved successfully.');
            redirect('coach_requests.php');
        } else {
            set_message('error', 'Failed to approve request. Please try again.');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approve Request - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include_once 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Approve Equipment Request</h5>
                    </div>
                    <div class="card-body">
                        <?php echo display_messages(); ?>
                        
                        <div class="alert alert-info">
                            <p><strong>Student:</strong> <?php echo htmlspecialchars($request['full_name'] ?: $request['username']); ?></p>
                            <p><strong>Equipment:</strong> <?php echo htmlspecialchars($request['equipment_name']); ?></p>
                            <p><strong>Quantity:</strong> <?php echo $request['quantity']; ?></p>
                            <p><strong>Request Date:</strong> <?php echo date('M d, Y', strtotime($request['request_date'])); ?></p>
                            <p><strong>Purpose:</strong> <?php echo htmlspecialchars($request['purpose']); ?></p>
                        </div>
                        
                        <form method="post" action="">
                            <div class="mb-3">
                                <label for="expected_return_date" class="form-label">Expected Return Date</label>
                                <input type="date" class="form-control" id="expected_return_date" name="expected_return_date" 
                                       value="<?php echo date('Y-m-d', strtotime('+7 days')); ?>" required>
                                <div class="form-text">Set the date by which the equipment should be returned.</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="notes" class="form-label">Notes (Optional)</label>
                                <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                                <div class="form-text">Add any special instructions or notes for the student.</div>
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <a href="coach_requests.php" class="btn btn-secondary">Cancel</a>
                                <button type="submit" class="btn btn-success">Approve Request</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>