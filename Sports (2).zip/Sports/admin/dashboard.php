<?php
session_start();
$page_title = "Admin Dashboard";
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and is admin
if (!is_logged_in() || !has_role('admin')) {
    redirect('../login.php?error=unauthorized');
}

// Get admin information
$admin = get_user($_SESSION['id']);

// Get dashboard statistics
$total_equipment = count_total_equipment();
$available_equipment = count_available_equipment();
$total_requests = count_total_requests();
$pending_requests = count_pending_requests();
$approved_requests = count_approved_requests();
$overdue_requests = count_overdue_requests();
$total_users = count_total_users();

// Get recent equipment requests
$recent_requests = get_recent_requests(5);

// Get low stock equipment
$low_stock = get_low_stock_equipment();

// Get overdue equipment
$overdue_equipment = get_overdue_equipment();

include_once 'includes/header.php';
?>

<!-- Add custom styles for background image -->
<style>
    body {
        position: relative;
        background-color: transparent !important;
    }
    
    body::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: url('../images/sgbit.jpg');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        opacity: 0.2;
        z-index: -1;
    }
</style>

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    <a href="reports.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
        <i class="fas fa-download fa-sm text-white-50 me-1"></i> Generate Report
    </a>
</div>

<!-- Content Row -->
<div class="row">
    <!-- Total Equipment Card -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col me-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Equipment</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_equipment; ?></div>
                        <div class="small mt-2"><?php echo $available_equipment; ?> available</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-dumbbell fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-transparent border-0 py-2">
                <a href="equipment.php" class="text-primary text-decoration-none small">
                    View Details <i class="fas fa-arrow-right ms-1"></i>
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <?php include_once 'includes/sidebar.php'; ?>
    </div>
    <div class="col-md-10">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-tachometer-alt me-2"></i> Admin Dashboard</h2>
            <div>
                <span class="text-muted me-2">Welcome, <?php echo htmlspecialchars($admin['username']); ?></span>
                <a href="profile.php" class="btn btn-outline-secondary btn-sm">
                    <i class="fas fa-user-cog"></i> Profile
                </a>
            </div>
        </div>
        
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card stat-card bg-primary text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title">Total Equipment</h6>
                                <div class="stat-value"><?php echo $total_equipment; ?></div>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-dumbbell"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <small><?php echo $available_equipment; ?> available</small>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent border-0">
                        <a href="equipment.php" class="text-white text-decoration-none small">
                            View Details <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stat-card bg-success text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title">Total Requests</h6>
                                <div class="stat-value"><?php echo $total_requests; ?></div>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-clipboard-list"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <small><?php echo $pending_requests; ?> pending approval</small>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent border-0">
                        <a href="requests.php" class="text-white text-decoration-none small">
                            View Details <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stat-card bg-danger text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title">Overdue Items</h6>
                                <div class="stat-value"><?php echo $overdue_requests; ?></div>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-exclamation-triangle"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <small>Requires immediate attention</small>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent border-0">
                        <a href="requests.php?status=overdue" class="text-white text-decoration-none small">
                            View Details <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stat-card bg-info text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title">Total Users</h6>
                                <div class="stat-value"><?php echo $total_users; ?></div>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                        <div class="mt-3">
                            <small>Coaches, Students & Admins</small>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent border-0">
                        <a href="users.php" class="text-white text-decoration-none small">
                            View Details <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="card mb-4">
            <div class="card-header bg-light">
                <h5 class="card-title mb-0">Quick Actions</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <a href="equipment.php?action=add" class="btn btn-primary d-block py-2">
                            <i class="fas fa-plus-circle me-2"></i> Add New Equipment
                        </a>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="requests.php?status=pending" class="btn btn-warning d-block py-2">
                            <i class="fas fa-tasks me-2"></i> Manage Pending Requests
                        </a>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="users.php?action=add" class="btn btn-success d-block py-2">
                            <i class="fas fa-user-plus me-2"></i> Add New User
                        </a>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="reports.php" class="btn btn-info d-block py-2">
                            <i class="fas fa-chart-bar me-2"></i> Generate Reports
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- Recent Requests -->
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Recent Requests</h5>
                        <a href="requests.php" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if (count($recent_requests) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Equipment</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recent_requests as $request): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($request['username']); ?></td>
                                                <td><?php echo htmlspecialchars($request['equipment_name']); ?></td>
                                                <td>
                                                    <?php 
                                                    $status_class = '';
                                                    switch ($request['status']) {
                                                        case 'pending':
                                                            $status_class = 'warning';
                                                            break;
                                                        case 'approved':
                                                            $status_class = 'success';
                                                            break;
                                                        case 'rejected':
                                                            $status_class = 'danger';
                                                            break;
                                                        case 'returned':
                                                            $status_class = 'info';
                                                            break;
                                                        case 'overdue':
                                                            $status_class = 'danger';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="badge bg-<?php echo $status_class; ?>">
                                                        <?php echo ucfirst($request['status']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M d, Y', strtotime($request['request_date'])); ?></td>
                                                <td>
                                                    <a href="request_details.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info mb-0">
                                <i class="fas fa-info-circle"></i> No recent requests found.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Low Stock & Overdue Items -->
            <div class="col-md-6">
                <!-- Low Stock Equipment -->
                <div class="card mb-4">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="card-title mb-0">Low Stock Equipment</h5>
                    </div>
                    <div class="card-body">
                        <?php if (count($low_stock) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Equipment</th>
                                            <th>Available</th>
                                            <th>Total</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($low_stock as $item): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['name']); ?></td>
                                                <td><?php echo $item['available']; ?></td>
                                                <td><?php echo $item['quantity']; ?></td>
                                                <td>
                                                    <a href="equipment.php?action=edit&id=<?php echo $item['id']; ?>" class="btn btn-sm btn-primary">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-success mb-0">
                                <i class="fas fa-check-circle"></i> All equipment has sufficient stock.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Overdue Equipment -->
                <div class="card">
                    <div class="card-header bg-danger text-white">
                        <h5 class="card-title mb-0">Overdue Equipment</h5>
                    </div>
                    <div class="card-body">
                        <?php if (count($overdue_equipment) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Equipment</th>
                                            <th>Due Date</th>
                                            <th>Days Overdue</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($overdue_equipment as $item): ?>
                                            <?php 
                                            $due_date = new DateTime($item['expected_return_date']);
                                            $today = new DateTime();
                                            $days_overdue = $today->diff($due_date)->days;
                                            ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['username']); ?></td>
                                                <td><?php echo htmlspecialchars($item['equipment_name']); ?></td>
                                                <td><?php echo date('M d, Y', strtotime($item['expected_return_date'])); ?></td>
                                                <td><?php echo $days_overdue; ?> days</td>
                                                <td>
                                                    <a href="send_reminder.php?id=<?php echo $item['id']; ?>" class="btn btn-sm btn-warning">
                                                        <i class="fas fa-bell"></i>
                                                    </a>
                                                    <a href="request_details.php?id=<?php echo $item['id']; ?>" class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-success mb-0">
                                <i class="fas fa-check-circle"></i> No overdue equipment at this time.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>

<script src="../assets/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>