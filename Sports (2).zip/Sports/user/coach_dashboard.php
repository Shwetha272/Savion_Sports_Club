<?php
$page_title = "Coach Dashboard";
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('../login.php');
}

// Check if user is coach
if (!has_role('coach')) {
    if (has_role('admin')) {
        redirect('../admin/dashboard.php');
    } elseif (has_role('student')) {
        redirect('dashboard.php');
    }
}

// Get user information
$user = get_user($_SESSION['id']);

// Get user equipment requests
$requests = get_user_requests($_SESSION['id']);

// Check for overdue equipment
check_overdue_equipment();

// Get available equipment count
$available_equipment = count_available_equipment();

// Get pending requests count
$pending_requests = count_user_pending_requests($_SESSION['id']);

// Get approved requests count
$approved_requests = count_user_approved_requests($_SESSION['id']);

// Get overdue requests count
$overdue_requests = count_user_overdue_requests($_SESSION['id']);

// Get coach's borrowing history
$history = get_user_borrowing_history($_SESSION['id'], 5);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            position: relative;
            background-color: transparent !important;
        }
        
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('../images/sgbit.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            opacity: 0.2;
            z-index: -1;
        }
    </style>
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include_once 'coach_sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0">Welcome, Coach <?php echo htmlspecialchars($user['username']); ?>!</h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> As a coach, you can borrow sports equipment for team activities and track your requests.
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-md-3">
                                <div class="card text-center h-100 border-primary">
                                    <div class="card-body">
                                        <i class="fas fa-dumbbell fa-3x text-primary mb-3"></i>
                                        <h5 class="card-title">Available Equipment</h5>
                                        <p class="card-text"><?php echo $available_equipment; ?> items available</p>
                                        <a href="equipment.php" class="btn btn-primary btn-sm">Browse</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-center h-100 border-warning">
                                    <div class="card-body">
                                        <i class="fas fa-clock fa-3x text-warning mb-3"></i>
                                        <h5 class="card-title">Pending Requests</h5>
                                        <p class="card-text"><?php echo $pending_requests; ?> pending</p>
                                        <a href="requests.php?status=pending" class="btn btn-warning btn-sm">View</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-center h-100 border-success">
                                    <div class="card-body">
                                        <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                                        <h5 class="card-title">Approved Items</h5>
                                        <p class="card-text"><?php echo $approved_requests; ?> to return</p>
                                        <a href="requests.php?status=approved" class="btn btn-success btn-sm">View</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-center h-100 border-danger">
                                    <div class="card-body">
                                        <i class="fas fa-exclamation-triangle fa-3x text-danger mb-3"></i>
                                        <h5 class="card-title">Overdue Items</h5>
                                        <p class="card-text"><?php echo $overdue_requests; ?> overdue</p>
                                        <a href="requests.php?status=overdue" class="btn btn-danger btn-sm">View</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="text-center mt-4">
                            <a href="equipment.php?action=request" class="btn btn-lg btn-primary">
                                <i class="fas fa-plus-circle me-2"></i> Request New Equipment
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Requests Section -->
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Recent Equipment Requests</h5>
                        <a href="requests.php" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if (count($requests) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Equipment</th>
                                            <th>Quantity</th>
                                            <th>Request Date</th>
                                            <th>Return By</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $count = 0;
                                        foreach ($requests as $request): 
                                            if ($count >= 5) break; // Show only 5 recent requests
                                            $count++;
                                            
                                            // Determine status class for badge
                                            $status_class = '';
                                            switch ($request['status']) {
                                                case 'pending':
                                                    $status_class = 'warning';
                                                    break;
                                                case 'approved':
                                                    $status_class = 'success';
                                                    break;
                                                case 'rejected':
                                                    $status_class = 'danger';
                                                    break;
                                                case 'returned':
                                                    $status_class = 'info';
                                                    break;
                                                case 'overdue':
                                                    $status_class = 'danger';
                                                    break;
                                            }
                                        ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($request['equipment_name']); ?></td>
                                                <td><?php echo $request['quantity']; ?></td>
                                                <td><?php echo date('M d, Y', strtotime($request['request_date'])); ?></td>
                                                <td><?php echo date('M d, Y', strtotime($request['expected_return_date'])); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php echo $status_class; ?>">
                                                        <?php echo ucfirst($request['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="request_details.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <?php if ($request['status'] == 'approved'): ?>
                                                    <a href="return_equipment.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-success">
                                                        <i class="fas fa-undo"></i>
                                                    </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> You haven't made any equipment requests yet.
                                <a href="equipment.php" class="alert-link">Browse equipment</a> to make a request.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Borrowing History Section -->
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Borrowing History</h5>
                        <a href="history.php" class="btn btn-sm btn-outline-secondary">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if (count($history) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Equipment</th>
                                            <th>Borrowed On</th>
                                            <th>Returned On</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($history as $item): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['equipment_name']); ?></td>
                                                <td><?php echo isset($item['approved_date']) && !empty($item['approved_date']) 
                                                    ? date('M d, Y', strtotime($item['approved_date'])) 
                                                    : 'Not approved yet'; ?></td>
                                                <td>
                                                    <?php 
                                                    echo !empty($item['actual_return_date']) 
                                                        ? date('M d, Y', strtotime($item['actual_return_date'])) 
                                                        : '–';
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php 
                                                    if ($item['status'] == 'returned') {
                                                        echo '<span class="badge bg-success">Returned</span>';
                                                    } elseif ($item['status'] == 'overdue') {
                                                        echo '<span class="badge bg-danger">Overdue</span>';
                                                    } else {
                                                        echo '<span class="badge bg-info">Active</span>';
                                                    }
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> You don't have any borrowing history yet.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Notifications Section -->
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5 class="card-title mb-0"><i class="fas fa-bell me-2"></i> Notifications</h5>
                    </div>
                    <div class="card-body">
                        <?php 
                        $notifications = get_user_notifications($_SESSION['id'], 3);
                        if (count($notifications) > 0):
                        ?>
                            <ul class="list-group">
                                <?php foreach ($notifications as $notification): ?>
                                <li class="list-group-item <?php echo $notification['is_read'] ? '' : 'list-group-item-warning'; ?>">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <?php if (!$notification['is_read']): ?>
                                            <span class="badge bg-danger me-2">New</span>
                                            <?php endif; ?>
                                            <?php echo htmlspecialchars($notification['message']); ?>
                                        </div>
                                        <small class="text-muted"><?php echo date('M d, g:i a', strtotime($notification['created_at'])); ?></small>
                                    </div>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                            <div class="text-center mt-3">
                                <a href="notifications.php" class="btn btn-sm btn-outline-info">View All Notifications</a>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info mb-0">
                                <i class="fas fa-info-circle"></i> You have no notifications at this time.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html>