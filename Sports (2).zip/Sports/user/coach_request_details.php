<?php
$page_title = "Request Details";
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('../login.php');
}

// Check if user is coach
if (!has_role('coach')) {
    set_message('error', 'You do not have permission to access this page.');
    redirect('dashboard.php');
}

// Check if request ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    set_message('error', 'Invalid request ID.');
    redirect('coach_requests.php');
}

$request_id = sanitize_input($_GET['id']);

// Get request details
$request = get_request_by_id($request_id);

// Check if request exists
if (!$request) {
    set_message('error', 'Request not found.');
    redirect('coach_requests.php');
}

// Get user details
$user = get_user_by_id($request['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include_once 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Request Details</h5>
                        <a href="coach_requests.php" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-arrow-left me-1"></i> Back to Requests
                        </a>
                    </div>
                    <div class="card-body">
                        <?php echo display_messages(); ?>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h6 class="border-bottom pb-2 mb-3">Request Information</h6>
                                <p><strong>Request ID:</strong> #<?php echo $request['id']; ?></p>
                                <p><strong>Status:</strong> 
                                    <?php 
                                    $status_class = '';
                                    $status_text = ucfirst($request['status']);
                                    
                                    switch ($request['status']) {
                                        case 'pending':
                                            $status_class = 'warning';
                                            break;
                                        case 'approved':
                                            $status_class = 'success';
                                            // Check if overdue
                                            if (strtotime($request['expected_return_date']) < time() && 
                                                empty($request['actual_return_date'])) {
                                                $status_class = 'danger';
                                                $status_text = 'Overdue';
                                            }
                                            break;
                                        case 'rejected':
                                            $status_class = 'danger';
                                            break;
                                        case 'returned':
                                            $status_class = 'info';
                                            break;
                                    }
                                    ?>
                                    <span class="badge bg-<?php echo $status_class; ?>"><?php echo $status_text; ?></span>
                                </p>
                                <p><strong>Request Date:</strong> <?php echo date('F d, Y h:i A', strtotime($request['request_date'])); ?></p>
                                <p><strong>Purpose:</strong> <?php echo htmlspecialchars($request['purpose']); ?></p>
                                
                                <?php if ($request['status'] == 'approved'): ?>
                                    <p><strong>Approved Date:</strong> <?php echo date('F d, Y', strtotime($request['approval_date'])); ?></p>
                                    <p><strong>Expected Return:</strong> <?php echo date('F d, Y', strtotime($request['expected_return_date'])); ?></p>
                                    <?php if (!empty($request['approval_notes'])): ?>
                                        <p><strong>Approval Notes:</strong> <?php echo htmlspecialchars($request['approval_notes']); ?></p>
                                    <?php endif; ?>
                                <?php endif; ?>
                                
                                <?php if ($request['status'] == 'rejected'): ?>
                                    <p><strong>Rejected Date:</strong> <?php echo date('F d, Y', strtotime($request['rejection_date'])); ?></p>
                                    <p><strong>Rejection Reason:</strong> <?php echo htmlspecialchars($request['rejection_reason']); ?></p>
                                <?php endif; ?>
                                
                                <?php if ($request['status'] == 'returned'): ?>
                                    <p><strong>Return Date:</strong> <?php echo date('F d, Y', strtotime($request['actual_return_date'])); ?></p>
                                    <p><strong>Return Condition:</strong> <?php echo htmlspecialchars($request['return_condition']); ?></p>
                                    <?php if (!empty($request['return_notes'])): ?>
                                        <p><strong>Return Notes:</strong> <?php echo htmlspecialchars($request['return_notes']); ?></p>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            
                            <div class="col-md-6">
                                <h6 class="border-bottom pb-2 mb-3">Student Information</h6>
                                <p><strong>Name:</strong> <?php echo htmlspecialchars($user['full_name'] ?: $user['username']); ?></p>
                                <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                                <p><strong>Phone:</strong> <?php echo !empty($user['phone']) ? htmlspecialchars($user['phone']) : 'Not provided'; ?></p>
                                
                                <h6 class="border-bottom pb-2 mb-3 mt-4">Equipment Information</h6>
                                <p><strong>Equipment:</strong> <?php echo htmlspecialchars($request['equipment_name']); ?></p>
                                <p><strong>Quantity:</strong> <?php echo $request['quantity']; ?></p>
                            </div>
                        </div>
                        
                        <?php if ($request['status'] == 'pending'): ?>
                            <div class="d-flex justify-content-end mt-3">
                                <a href="coach_reject_request.php?id=<?php echo $request['id']; ?>" class="btn btn-danger me-2">
                                    <i class="fas fa-times me-1"></i> Reject
                                </a>
                                <a href="coach_approve_request.php?id=<?php echo $request['id']; ?>" class="btn btn-success">
                                    <i class="fas fa-check me-1"></i> Approve
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($request['status'] == 'approved' && empty($request['actual_return_date'])): ?>
                            <div class="d-flex justify-content-end mt-3">
                                <a href="coach_mark_returned.php?id=<?php echo $request['id']; ?>" class="btn btn-primary">
                                    <i class="fas fa-undo me-1"></i> Mark as Returned
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>