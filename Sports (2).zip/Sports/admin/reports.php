<?php
require_once '../includes/functions.php';
require_once '../includes/config.php';

// Check if user is logged in and is an admin
if (!is_logged_in()) {
    redirect('/Sports/login.php');
}

if (!has_role('admin')) {
    redirect('/Sports/403.php');
}

// Process PDF generation if requested
if (isset($_GET['export']) && $_GET['export'] == 'pdf') {
    // Include TCPDF library
    require_once('../vendor/tcpdf/tcpdf.php');
    
    // Get report type
    $report_type = isset($_GET['type']) ? $_GET['type'] : 'equipment';
    
    // Create new PDF document
    $pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
    
    // Set document information
    $pdf->SetCreator('Sports Equipment Management');
    $pdf->SetAuthor('Admin');
    $pdf->SetTitle('Equipment Report');
    $pdf->SetSubject('Equipment Management Report');
    
    // Set default header data
    $pdf->SetHeaderData('', 0, 'Sports Equipment Management', 'Generated on: ' . date('Y-m-d H:i:s'));
    
    // Set margins
    $pdf->SetMargins(15, 20, 15);
    $pdf->SetHeaderMargin(10);
    $pdf->SetFooterMargin(10);
    
    // Set auto page breaks
    $pdf->SetAutoPageBreak(TRUE, 15);
    
    // Add a page
    $pdf->AddPage();
    
    // Set font
    $pdf->SetFont('helvetica', 'B', 16);
    
    // Generate report content based on type
    switch ($report_type) {
        case 'equipment':
            $pdf->Cell(0, 10, 'Equipment Inventory Report', 0, 1, 'C');
            $pdf->SetFont('helvetica', '', 10);
            
            // Create table header
            $pdf->SetFillColor(230, 230, 230);
            $pdf->Cell(10, 7, 'ID', 1, 0, 'C', 1);
            $pdf->Cell(50, 7, 'Name', 1, 0, 'C', 1);
            $pdf->Cell(30, 7, 'Category', 1, 0, 'C', 1);
            $pdf->Cell(20, 7, 'Quantity', 1, 0, 'C', 1);
            $pdf->Cell(20, 7, 'Available', 1, 0, 'C', 1);
            $pdf->Cell(30, 7, 'Status', 1, 0, 'C', 1);
            $pdf->Cell(30, 7, 'Location', 1, 1, 'C', 1);
            
            // Get equipment data
            $equipment = get_all_equipment();
            
            // Add data rows
            foreach ($equipment as $item) {
                $pdf->Cell(10, 6, $item['id'], 1, 0, 'C');
                $pdf->Cell(50, 6, $item['name'], 1, 0, 'L');
                $pdf->Cell(30, 6, get_category_name($item['category_id']), 1, 0, 'L');
                $pdf->Cell(20, 6, $item['quantity'], 1, 0, 'C');
                $pdf->Cell(20, 6, $item['available'], 1, 0, 'C');
                $pdf->Cell(30, 6, ucfirst(str_replace('_', ' ', $item['status'])), 1, 0, 'C');
                $pdf->Cell(30, 6, $item['location'], 1, 1, 'L');
            }
            break;
            
        case 'requests':
            $pdf->Cell(0, 10, 'Equipment Requests Report', 0, 1, 'C');
            $pdf->SetFont('helvetica', '', 10);
            
            // Create table header
            $pdf->SetFillColor(230, 230, 230);
            $pdf->Cell(10, 7, 'ID', 1, 0, 'C', 1);
            $pdf->Cell(40, 7, 'Equipment', 1, 0, 'C', 1);
            $pdf->Cell(30, 7, 'User', 1, 0, 'C', 1);
            $pdf->Cell(25, 7, 'Request Date', 1, 0, 'C', 1);
            $pdf->Cell(25, 7, 'Return Date', 1, 0, 'C', 1);
            $pdf->Cell(30, 7, 'Status', 1, 1, 'C', 1);
            
            // Get request data
            $requests = get_all_requests();
            
            // Add data rows
            foreach ($requests as $request) {
                $equipment = get_equipment($request['equipment_id']);
                $user = get_user($request['user_id']);
                
                $pdf->Cell(10, 6, $request['id'], 1, 0, 'C');
                $pdf->Cell(40, 6, $equipment['name'], 1, 0, 'L');
                $pdf->Cell(30, 6, $user['username'], 1, 0, 'L');
                $pdf->Cell(25, 6, date('Y-m-d', strtotime($request['request_date'])), 1, 0, 'C');
                $pdf->Cell(25, 6, date('Y-m-d', strtotime($request['expected_return_date'])), 1, 0, 'C');
                $pdf->Cell(30, 6, ucfirst($request['status']), 1, 1, 'C');
            }
            break;
            
        case 'overdue':
            $pdf->Cell(0, 10, 'Overdue Equipment Report', 0, 1, 'C');
            $pdf->SetFont('helvetica', '', 10);
            
            // Create table header
            $pdf->SetFillColor(230, 230, 230);
            $pdf->Cell(10, 7, 'ID', 1, 0, 'C', 1);
            $pdf->Cell(40, 7, 'Equipment', 1, 0, 'C', 1);
            $pdf->Cell(30, 7, 'User', 1, 0, 'C', 1);
            $pdf->Cell(25, 7, 'Borrow Date', 1, 0, 'C', 1);
            $pdf->Cell(25, 7, 'Due Date', 1, 0, 'C', 1);
            $pdf->Cell(30, 7, 'Days Overdue', 1, 1, 'C', 1);
            
            // Get overdue data
            $overdue = get_overdue_requests();
            
            // Add data rows
            foreach ($overdue as $request) {
                $equipment = get_equipment($request['equipment_id']);
                $user = get_user($request['user_id']);
                $days_overdue = floor((time() - strtotime($request['expected_return_date'])) / (60 * 60 * 24));
                
                $pdf->Cell(10, 6, $request['id'], 1, 0, 'C');
                $pdf->Cell(40, 6, $equipment['name'], 1, 0, 'L');
                $pdf->Cell(30, 6, $user['username'], 1, 0, 'L');
                $pdf->Cell(25, 6, date('Y-m-d', strtotime($request['approval_date'])), 1, 0, 'C');
                $pdf->Cell(25, 6, date('Y-m-d', strtotime($request['expected_return_date'])), 1, 0, 'C');
                $pdf->Cell(30, 6, $days_overdue, 1, 1, 'C');
            }
            break;
    }
    
    // Output PDF
    $pdf->Output('equipment_report_' . date('Y-m-d') . '.pdf', 'D');
    exit;
}

// Get page title
$page_title = "Reports";
?>

<!-- Add custom styles for background image -->
<style>
    body {
        position: relative;
        background-color: transparent !important;
    }
    
    body::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: url('../images/sgbit.jpg');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        opacity: 0.2;
        z-index: -1;
    }
</style>

<?php
include_once '../includes/header.php';
?>

<div class="container py-4">
    <h1 class="mb-4">Reports</h1>
    
    <?php echo display_messages(); ?>
    
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Equipment Inventory</h5>
                </div>
                <div class="card-body">
                    <p class="card-text">View and export a complete inventory of all equipment in the system.</p>
                    <p><strong>Total Equipment:</strong> <?php echo count_total_equipment(); ?></p>
                    <p><strong>Available Equipment:</strong> <?php echo count_available_equipment(); ?></p>
                </div>
                <div class="card-footer">
                    <a href="?export=pdf&type=equipment" class="btn btn-primary">Export to PDF</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-header bg-success text-white">
                    <h5 class="card-title mb-0">Equipment Requests</h5>
                </div>
                <div class="card-body">
                    <p class="card-text">View and export a report of all equipment requests.</p>
                    <p><strong>Total Requests:</strong> <?php echo count_total_requests(); ?></p>
                    <p><strong>Pending Requests:</strong> <?php echo count_pending_requests(); ?></p>
                </div>
                <div class="card-footer">
                    <a href="?export=pdf&type=requests" class="btn btn-success">Export to PDF</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-header bg-danger text-white">
                    <h5 class="card-title mb-0">Overdue Equipment</h5>
                </div>
                <div class="card-body">
                    <p class="card-text">View and export a report of all overdue equipment.</p>
                    <p><strong>Overdue Items:</strong> <?php echo count_overdue_requests(); ?></p>
                </div>
                <div class="card-footer">
                    <a href="?export=pdf&type=overdue" class="btn btn-danger">Export to PDF</a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mt-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5 class="card-title mb-0">Custom Report</h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="">
                        <input type="hidden" name="export" value="pdf">
                        
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="type" class="form-label">Report Type</label>
                                    <select class="form-select" id="type" name="type">
                                        <option value="equipment">Equipment Inventory</option>
                                        <option value="requests">Equipment Requests</option>
                                        <option value="overdue">Overdue Equipment</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="date_range" class="form-label">Date Range</label>
                                    <select class="form-select" id="date_range" name="date_range">
                                        <option value="all">All Time</option>
                                        <option value="today">Today</option>
                                        <option value="week">This Week</option>
                                        <option value="month">This Month</option>
                                        <option value="year">This Year</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-md-4 d-flex align-items-end">
                                <button type="submit" class="btn btn-info mb-3">Generate Report</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>