<?php
$page_title = "Equipment";
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('../login.php');
}

// Check if user is student or coach
if (has_role('admin')) {
    redirect('../admin/dashboard.php');
}

// Get all equipment with direct database query to match admin format
$sql = "SELECT id, name, description, quantity, available, location, status, image 
        FROM equipment";
$result = mysqli_query($conn, $sql);

// Update available quantities to match total quantities for available items
$update_sql = "UPDATE equipment SET available = quantity WHERE status = 'available'";
mysqli_query($conn, $update_sql);

// Fetch the updated equipment data
$sql = "SELECT id, name, description, quantity, available, location, status, image 
        FROM equipment";
$result = mysqli_query($conn, $sql);

$equipment = [];
while ($row = mysqli_fetch_assoc($result)) {
    $equipment[] = $row;
}

// Process equipment request form
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['request_equipment'])) {
    $equipment_id = sanitize_input($_POST['equipment_id']);
    $quantity = sanitize_input($_POST['quantity']);
    $expected_return_date = sanitize_input($_POST['expected_return_date']);
    $notes = sanitize_input($_POST['notes']);
    $user_id = $_SESSION['id'];
    $error = "";
    $success = "";
    
    // Validate input
    if (empty($equipment_id) || empty($quantity) || empty($expected_return_date)) {
        $error = "Please fill all required fields.";
    } elseif (!is_numeric($quantity) || $quantity <= 0) {
        $error = "Please enter a valid quantity.";
    } else {
        // Check if equipment exists and has enough available items
        $equipment_item = get_equipment($equipment_id);
        if (!$equipment_item) {
            $error = "Equipment not found.";
        } elseif ($equipment_item['available'] < $quantity) {
            $error = "Not enough items available. Only {$equipment_item['available']} available.";
        } else {
            // Insert equipment request
            $sql = "INSERT INTO equipment_requests (user_id, equipment_id, quantity, expected_return_date, notes) 
                    VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "iiiss", $user_id, $equipment_id, $quantity, $expected_return_date, $notes);
            
            if (mysqli_stmt_execute($stmt)) {
                // Create notification for admin
                $admin_message = "New equipment request from " . $_SESSION['username'] . " for " . $equipment_item['name'] . ".";
                create_admin_notification($admin_message, 'request_update');
                
                // Create notification for user
                $user_message = "Your request for " . $equipment_item['name'] . " has been submitted and is pending approval.";
                create_user_notification($user_id, $user_message, 'request_update');
                
                $success = "Equipment request submitted successfully. You will be notified when it's approved.";
            } else {
                $error = "Something went wrong. Please try again later.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            position: relative;
            background-color: transparent !important;
        }
        
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('../images/sgbit.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            opacity: 0.2;
            z-index: -1;
        }
    </style>
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include_once 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <?php if (isset($_GET['action']) && $_GET['action'] == 'request'): ?>
                    <!-- Equipment Request Form -->
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="card-title mb-0">Request Equipment</h5>
                        </div>
                        <div class="card-body">
                            <?php if (isset($error) && !empty($error)): ?>
                                <div class="alert alert-danger"><?php echo $error; ?></div>
                            <?php endif; ?>
                            
                            <?php if (isset($success) && !empty($success)): ?>
                                <div class="alert alert-success"><?php echo $success; ?></div>
                            <?php endif; ?>
                            
                            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?action=request" method="post">
                                <div class="mb-3">
                                    <label for="equipment_id" class="form-label">Select Equipment</label>
                                    <select class="form-select" id="equipment_id" name="equipment_id" required>
                                        <option value="">Select Equipment</option>
                                        <?php foreach ($equipment as $item): ?>
                                            <option value="<?php echo $item['id']; ?>" data-available="<?php echo $item['available']; ?>">
                                                <?php echo htmlspecialchars($item['name']); ?> 
                                                (<?php echo $item['available']; ?> available)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="quantity" class="form-label">Quantity</label>
                                    <input type="number" class="form-control" id="quantity" name="quantity" min="1" value="1" required>
                                    <small class="text-muted">Maximum available: <span id="max-available">0</span></small>
                                </div>
                                <div class="mb-3">
                                    <label for="expected_return_date" class="form-label">Expected Return Date</label>
                                    <input type="date" class="form-control" id="expected_return_date" name="expected_return_date" required>
                                    <small class="text-muted">Please select a date within the next 30 days</small>
                                </div>
                                <div class="mb-3">
                                    <label for="notes" class="form-label">Notes (Optional)</label>
                                    <textarea class="form-control" id="notes" name="notes" rows="3" placeholder="Reason for borrowing, specific requirements, etc."></textarea>
                                </div>
                                <div class="d-grid gap-2">
                                    <button type="submit" name="request_equipment" class="btn btn-primary">Submit Request</button>
                                    <a href="equipment.php" class="btn btn-outline-secondary">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Equipment List -->
                    <div class="card mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">Available Equipment</h5>
                            <a href="equipment.php?action=request" class="btn btn-primary">
                                <i class="fas fa-plus-circle me-2"></i> Request Equipment
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Equipment</th>
                                            <th>Description</th>
                                            <th>Available</th>
                                            <th>Location</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($equipment as $item): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['name']); ?></td>
                                                <td><?php echo htmlspecialchars($item['description']); ?></td>
                                                <td><?php echo $item['available']; ?> / <?php echo $item['quantity']; ?></td>
                                                <td><?php echo htmlspecialchars($item['location']); ?></td>
                                                <td>
                                                    <?php 
                                                    $status_class = '';
                                                    switch ($item['status']) {
                                                        case 'available':
                                                            $status_class = 'success';
                                                            break;
                                                        case 'low_stock':
                                                            $status_class = 'warning';
                                                            break;
                                                        case 'out_of_stock':
                                                            $status_class = 'danger';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="badge bg-<?php echo $status_class; ?>">
                                                        <?php echo ucfirst(str_replace('_', ' ', $item['status'])); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php if ($item['available'] > 0): ?>
                                                        <a href="equipment.php?action=request&id=<?php echo $item['id']; ?>" class="btn btn-sm btn-primary">
                                                            <i class="fas fa-plus-circle"></i> Request
                                                        </a>
                                                    <?php else: ?>
                                                        <button class="btn btn-sm btn-secondary" disabled>
                                                            <i class="fas fa-ban"></i> Unavailable
                                                        </button>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
    <script>
        // Update max available quantity when equipment is selected
        document.addEventListener('DOMContentLoaded', function() {
            const equipmentSelect = document.getElementById('equipment_id');
            const quantityInput = document.getElementById('quantity');
            const maxAvailableSpan = document.getElementById('max-available');
            
            if (equipmentSelect && quantityInput && maxAvailableSpan) {
                equipmentSelect.addEventListener('change', function() {
                    const selectedOption = this.options[this.selectedIndex];
                    const availableQuantity = selectedOption.getAttribute('data-available');
                    
                    if (availableQuantity) {
                        maxAvailableSpan.textContent = availableQuantity;
                        quantityInput.max = availableQuantity;
                        
                        if (parseInt(quantityInput.value) > parseInt(availableQuantity)) {
                            quantityInput.value = availableQuantity;
                        }
                    } else {
                        maxAvailableSpan.textContent = '0';
                        quantityInput.max = 0;
                    }
                });
                
                // Set min date to today and max date to 30 days from now
                const returnDateInput = document.getElementById('expected_return_date');
                if (returnDateInput) {
                    const today = new Date();
                    const maxDate = new Date();
                    maxDate.setDate(today.getDate() + 30);
                    
                    const formatDate = (date) => {
                        const year = date.getFullYear();
                        const month = String(date.getMonth() + 1).padStart(2, '0');
                        const day = String(date.getDate()).padStart(2, '0');
                        return `${year}-${month}-${day}`;
                    };
                    
                    returnDateInput.min = formatDate(today);
                    returnDateInput.max = formatDate(maxDate);
                    returnDateInput.value = formatDate(today);
                }
                
                // Pre-select equipment if ID is provided in URL
                const urlParams = new URLSearchParams(window.location.search);
                const equipmentId = urlParams.get('id');
                if (equipmentId) {
                    for (let i = 0; i < equipmentSelect.options.length; i++) {
                        if (equipmentSelect.options[i].value === equipmentId) {
                            equipmentSelect.selectedIndex = i;
                            // Trigger change event to update max available
                            const event = new Event('change');
                            equipmentSelect.dispatchEvent(event);
                            break;
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
