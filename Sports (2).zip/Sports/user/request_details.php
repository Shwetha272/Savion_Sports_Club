<?php
$page_title = "Request Details";
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('../login.php');
}

// Check if user is student or coach
if (has_role('admin')) {
    redirect('../admin/dashboard.php');
}

// Check if request ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    set_message('error', 'Invalid request ID.');
    redirect('my_requests.php');
}

$request_id = sanitize_input($_GET['id']);
$user_id = $_SESSION['id'];

// Get request details with equipment information
$sql = "SELECT er.*, e.name as equipment_name, e.description, e.image 
        FROM equipment_requests er
        JOIN equipment e ON er.equipment_id = e.id
        WHERE er.id = ? AND er.user_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $request_id, $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {
    set_message('error', 'Request not found or you do not have permission to view it.');
    redirect('my_requests.php');
}

$request = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include_once 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Request Details</h5>
                        <a href="my_requests.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-2"></i> Back to My Requests
                        </a>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <?php if (!empty($request['image']) && file_exists("../uploads/equipment/" . $request['image'])): ?>
                                    <img src="../uploads/equipment/<?php echo $request['image']; ?>" class="img-fluid rounded" alt="<?php echo htmlspecialchars($request['equipment_name']); ?>">
                                <?php else: ?>
                                    <img src="../assets/images/equipment-placeholder.jpg" class="img-fluid rounded" alt="Equipment Image Placeholder">
                                <?php endif; ?>
                            </div>
                            <div class="col-md-8">
                                <h4><?php echo htmlspecialchars($request['equipment_name']); ?></h4>
                                <p class="text-muted"><?php echo htmlspecialchars($request['description']); ?></p>
                                
                                <div class="table-responsive mt-3">
                                    <table class="table table-bordered">
                                        <tbody>
                                            <tr>
                                                <th style="width: 30%">Request ID</th>
                                                <td><?php echo $request['id']; ?></td>
                                            </tr>
                                            <tr>
                                                <th>Status</th>
                                                <td>
                                                    <?php 
                                                    $status_class = '';
                                                    switch ($request['status']) {
                                                        case 'pending':
                                                            $status_class = 'warning';
                                                            break;
                                                        case 'approved':
                                                            $status_class = 'success';
                                                            break;
                                                        case 'rejected':
                                                            $status_class = 'danger';
                                                            break;
                                                        case 'returned':
                                                            $status_class = 'info';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="badge bg-<?php echo $status_class; ?>">
                                                        <?php echo ucfirst($request['status']); ?>
                                                    </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Quantity</th>
                                                <td><?php echo $request['quantity']; ?></td>
                                            </tr>
                                            <tr>
                                                <th>Request Date</th>
                                                <td><?php echo date('F j, Y', strtotime($request['request_date'])); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Expected Return Date</th>
                                                <td><?php echo date('F j, Y', strtotime($request['expected_return_date'])); ?></td>
                                            </tr>
                                            <?php if (!empty($request['actual_return_date'])): ?>
                                            <tr>
                                                <th>Actual Return Date</th>
                                                <td><?php echo date('F j, Y', strtotime($request['actual_return_date'])); ?></td>
                                            </tr>
                                            <?php endif; ?>
                                            <?php if (!empty($request['notes'])): ?>
                                            <tr>
                                                <th>Notes</th>
                                                <td><?php echo nl2br(htmlspecialchars($request['notes'])); ?></td>
                                            </tr>
                                            <?php endif; ?>
                                            <?php if (!empty($request['admin_notes'])): ?>
                                            <tr>
                                                <th>Admin Notes</th>
                                                <td><?php echo nl2br(htmlspecialchars($request['admin_notes'])); ?></td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                
                                <?php if ($request['status'] == 'pending'): ?>
                                <div class="mt-3">
                                    <a href="cancel_request.php?id=<?php echo $request['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to cancel this request?');">
                                        <i class="fas fa-times-circle me-2"></i> Cancel Request
                                    </a>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>