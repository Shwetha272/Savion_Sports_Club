<?php
$page_title = "Register";
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Check if user is already logged in
if (is_logged_in()) {
    if (has_role('admin')) {
        redirect('admin/dashboard.php');
    } else {
        redirect('user/dashboard.php');
    }
}

// If role is selected, redirect to appropriate registration page
if (isset($_GET['role'])) {
    $role = sanitize_input($_GET['role']);
    if ($role == 'student') {
        redirect('register_student.php');
    } elseif ($role == 'coach') {
        redirect('register_coach.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@400;500;600;700;800&display=swap');
        
        :root {
            --primary-color: #3498db;
            --secondary-color: #2ecc71;
            --accent-color: #e74c3c;
            --gradient-1: linear-gradient(45deg, #3498db, #2ecc71);
            --gradient-2: linear-gradient(135deg, #e74c3c, #f39c12);
            --gradient-3: linear-gradient(90deg, #9b59b6, #3498db);
        }
        
        body {
            position: relative;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('images/sgbit.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            opacity: 0.2;
            z-index: -1;
        }
        
        .navbar {
            background: var(--gradient-1) !important;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .navbar-brand {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            letter-spacing: 1px;
        }
        
        .auth-form {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin: 50px auto;
            max-width: 900px;
            border-top: 5px solid var(--primary-color);
            border-bottom: 5px solid var(--secondary-color);
            position: relative;
            overflow: hidden;
        }
        
        .auth-form::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(52, 152, 219, 0.05) 0%, rgba(46, 204, 113, 0.05) 100%);
            z-index: -1;
        }
        
        .form-title {
            font-family: 'Montserrat', sans-serif;
            font-weight: 800;
            text-align: center;
            margin-bottom: 20px;
            background: var(--gradient-1);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            letter-spacing: 1px;
        }
        
        .card {
            border: none;
            border-radius: 15px;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            height: 100%;
        }
        
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }
        
        .card-body {
            padding: 30px;
            position: relative;
            z-index: 1;
        }
        
        .card-body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(52, 152, 219, 0.03) 0%, rgba(46, 204, 113, 0.03) 100%);
            z-index: -1;
        }
        
        .card h3 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            margin: 15px 0;
            color: #2c3e50;
        }
        
        .card p {
            color: #7f8c8d;
            margin-bottom: 20px;
            font-size: 1.1rem;
        }
        
        .btn {
            border-radius: 30px;
            padding: 12px 25px;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .btn-primary {
            background: var(--gradient-1);
            border: none;
        }
        
        .btn-primary:hover {
            background: linear-gradient(45deg, #2980b9, #27ae60);
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4);
        }
        
        .text-center a {
            color: var(--primary-color);
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .text-center a:hover {
            color: var(--secondary-color);
        }
        
        .fa-user-graduate, .fa-user-tie {
            background: var(--gradient-1);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
    </style>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <strong>Savion Sports Club</strong>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="register.php">Register</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="auth-form animate__animated animate__fadeIn">
            <h2 class="form-title animate__animated animate__fadeInDown">Register for Savion Sports Club</h2>
            <p class="text-center mb-4 animate__animated animate__fadeIn animate__delay-1s" style="font-size: 1.1rem; color: #34495e;">Please select your role to continue registration</p>
            
            <div class="row mt-4">
                <div class="col-md-6" data-aos="fade-right" data-aos-delay="200">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-user-graduate fa-4x mb-3 text-primary animate__animated animate__pulse animate__infinite"></i>
                            <h3>Student</h3>
                            <p>Register as a student to borrow sports equipment</p>
                            <a href="register.php?role=student" class="btn btn-primary mt-3">Register as Student</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6" data-aos="fade-left" data-aos-delay="400">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-user-tie fa-4x mb-3 text-primary animate__animated animate__pulse animate__infinite"></i>
                            <h3>Coach</h3>
                            <p>Register as a coach to manage sports activities</p>
                            <a href="register.php?role=coach" class="btn btn-primary mt-3">Register as Coach</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="mt-5 text-center animate__animated animate__fadeIn animate__delay-2s">
                <p style="font-size: 1.1rem;">Already have an account? <a href="login.php">Login here</a></p>
                <a href="index.php" class="btn btn-outline-primary mt-2">Back to Home</a>
            </div>
        </div>
    </div>
    
    <footer class="mt-auto py-4 bg-dark text-white">
        <div class="container text-center">
            <p>&copy; <?php echo date('Y'); ?> Savion Sports Club. All rights reserved.</p>
        </div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        // Initialize AOS
        AOS.init({
            duration: 800,
            easing: 'ease-out-cubic',
            once: false
        });
    </script>
</body>
</html>