<?php
$page_title = "Equipment Requests";
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('../login.php');
}

// Check if user is coach
if (!has_role('coach')) {
    set_message('error', 'You do not have permission to access this page.');
    redirect('dashboard.php');
}

// Get all requests for coach to review
$status_filter = isset($_GET['status']) ? sanitize_input($_GET['status']) : '';

// Get requests for coach to review
$sql = "SELECT er.*, e.name as equipment_name, u.username, u.email, u.full_name 
        FROM equipment_requests er
        JOIN equipment e ON er.equipment_id = e.id
        JOIN users u ON er.user_id = u.id";

// Add status filter if provided
if (!empty($status_filter)) {
    if ($status_filter == 'overdue') {
        $sql .= " WHERE er.status = 'approved' AND er.expected_return_date < CURDATE() AND er.actual_return_date IS NULL";
    } else {
        $sql .= " WHERE er.status = ?";
    }
}

$sql .= " ORDER BY er.request_date DESC";

$stmt = mysqli_prepare($conn, $sql);

// Bind status parameter if filtering
if (!empty($status_filter) && $status_filter != 'overdue') {
    mysqli_stmt_bind_param($stmt, "s", $status_filter);
}

mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$requests = [];
while ($row = mysqli_fetch_assoc($result)) {
    $requests[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include_once 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Equipment Requests</h5>
                    </div>
                    <div class="card-body">
                        <!-- Status filter buttons -->
                        <div class="mb-4">
                            <div class="btn-group" role="group">
                                <a href="coach_requests.php" class="btn btn-outline-secondary <?php echo empty($status_filter) ? 'active' : ''; ?>">All</a>
                                <a href="coach_requests.php?status=pending" class="btn btn-outline-warning <?php echo $status_filter == 'pending' ? 'active' : ''; ?>">Pending</a>
                                <a href="coach_requests.php?status=approved" class="btn btn-outline-success <?php echo $status_filter == 'approved' ? 'active' : ''; ?>">Approved</a>
                                <a href="coach_requests.php?status=rejected" class="btn btn-outline-danger <?php echo $status_filter == 'rejected' ? 'active' : ''; ?>">Rejected</a>
                                <a href="coach_requests.php?status=returned" class="btn btn-outline-info <?php echo $status_filter == 'returned' ? 'active' : ''; ?>">Returned</a>
                                <a href="coach_requests.php?status=overdue" class="btn btn-outline-danger <?php echo $status_filter == 'overdue' ? 'active' : ''; ?>">Overdue</a>
                            </div>
                        </div>
                        
                        <?php echo display_messages(); ?>
                        
                        <?php if (count($requests) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Student</th>
                                            <th>Equipment</th>
                                            <th>Quantity</th>
                                            <th>Request Date</th>
                                            <th>Return By</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($requests as $request): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($request['full_name'] ?: $request['username']); ?></td>
                                                <td><?php echo htmlspecialchars($request['equipment_name']); ?></td>
                                                <td><?php echo $request['quantity']; ?></td>
                                                <td><?php echo date('M d, Y', strtotime($request['request_date'])); ?></td>
                                                <td><?php echo date('M d, Y', strtotime($request['expected_return_date'])); ?></td>
                                                <td>
                                                    <?php 
                                                    $status_class = '';
                                                    $status_text = ucfirst($request['status']);
                                                    
                                                    switch ($request['status']) {
                                                        case 'pending':
                                                            $status_class = 'warning';
                                                            break;
                                                        case 'approved':
                                                            $status_class = 'success';
                                                            // Check if overdue
                                                            if (strtotime($request['expected_return_date']) < time() && 
                                                                empty($request['actual_return_date'])) {
                                                                $status_class = 'danger';
                                                                $status_text = 'Overdue';
                                                            }
                                                            break;
                                                        case 'rejected':
                                                            $status_class = 'danger';
                                                            break;
                                                        case 'returned':
                                                            $status_class = 'info';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="badge bg-<?php echo $status_class; ?>">
                                                        <?php echo $status_text; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="coach_request_details.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i> Details
                                                    </a>
                                                    <?php if ($request['status'] == 'pending'): ?>
                                                    <a href="coach_approve_request.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-success">
                                                        <i class="fas fa-check"></i> Approve
                                                    </a>
                                                    <a href="coach_reject_request.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-danger">
                                                        <i class="fas fa-times"></i> Reject
                                                    </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> 
                                <?php if (empty($status_filter)): ?>
                                    There are no equipment requests to review.
                                <?php else: ?>
                                    No <?php echo $status_filter; ?> requests found.
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>