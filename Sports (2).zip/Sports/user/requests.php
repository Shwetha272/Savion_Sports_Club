<?php
$page_title = "My Requests";
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('../login.php');
}

// Check if user is student or coach
if (has_role('admin')) {
    redirect('../admin/dashboard.php');
}

// Get user requests
$status_filter = isset($_GET['status']) ? sanitize_input($_GET['status']) : '';
$requests = get_user_requests_with_filter($_SESSION['id'], $status_filter);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            position: relative;
            background-color: transparent !important;
        }
        
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('../images/sgbit.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            opacity: 0.2;
            z-index: -1;
        }
    </style>
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include_once 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">My Equipment Requests</h5>
                        <a href="equipment.php?action=request" class="btn btn-primary">
                            <i class="fas fa-plus-circle me-2"></i> New Request
                        </a>
                    </div>
                    <div class="card-body">
                        <!-- Status filter buttons -->
                        <div class="mb-4">
                            <div class="btn-group" role="group">
                                <a href="requests.php" class="btn btn-outline-secondary <?php echo empty($status_filter) ? 'active' : ''; ?>">All</a>
                                <a href="requests.php?status=pending" class="btn btn-outline-warning <?php echo $status_filter == 'pending' ? 'active' : ''; ?>">Pending</a>
                                <a href="requests.php?status=approved" class="btn btn-outline-success <?php echo $status_filter == 'approved' ? 'active' : ''; ?>">Approved</a>
                                <a href="requests.php?status=rejected" class="btn btn-outline-danger <?php echo $status_filter == 'rejected' ? 'active' : ''; ?>">Rejected</a>
                                <a href="requests.php?status=returned" class="btn btn-outline-info <?php echo $status_filter == 'returned' ? 'active' : ''; ?>">Returned</a>
                                <a href="requests.php?status=overdue" class="btn btn-outline-danger <?php echo $status_filter == 'overdue' ? 'active' : ''; ?>">Overdue</a>
                            </div>
                        </div>
                        
                        <?php if (count($requests) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Equipment</th>
                                            <th>Quantity</th>
                                            <th>Request Date</th>
                                            <th>Return By</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($requests as $request): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($request['equipment_name']); ?></td>
                                                <td><?php echo $request['quantity']; ?></td>
                                                <td><?php echo date('M d, Y', strtotime($request['request_date'])); ?></td>
                                                <td><?php echo date('M d, Y', strtotime($request['expected_return_date'])); ?></td>
                                                <td>
                                                    <?php 
                                                    $status_class = '';
                                                    switch ($request['status']) {
                                                        case 'pending':
                                                            $status_class = 'warning';
                                                            break;
                                                        case 'approved':
                                                            $status_class = 'success';
                                                            break;
                                                        case 'rejected':
                                                            $status_class = 'danger';
                                                            break;
                                                        case 'returned':
                                                            $status_class = 'info';
                                                            break;
                                                        case 'overdue':
                                                            $status_class = 'danger';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="badge bg-<?php echo $status_class; ?>">
                                                        <?php echo ucfirst($request['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="request_details.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i> Details
                                                    </a>
                                                    <?php if ($request['status'] == 'approved'): ?>
                                                    <a href="return_equipment.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-success">
                                                        <i class="fas fa-undo"></i> Return
                                                    </a>
                                                    <?php endif; ?>
                                                    <?php if ($request['status'] == 'pending'): ?>
                                                    <a href="cancel_request.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to cancel this request?');">
                                                        <i class="fas fa-times"></i> Cancel
                                                    </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> 
                                <?php if (empty($status_filter)): ?>
                                    You haven't made any equipment requests yet.
                                <?php else: ?>
                                    No <?php echo $status_filter; ?> requests found.
                                <?php endif; ?>
                                <a href="equipment.php" class="alert-link">Browse equipment</a> to make a request.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>