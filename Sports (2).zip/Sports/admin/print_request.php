<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and is an admin
if (!is_logged_in() || !has_role('admin')) {
    redirect('../login.php?error=unauthorized');
}

// Get request ID from URL
$request_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// If no valid ID provided, redirect to requests page
if ($request_id <= 0) {
    redirect('requests.php?error=invalid_request');
}

// Get request details
$request = get_request_by_id($request_id);

// If request not found, redirect to requests page
if (!$request) {
    redirect('requests.php?error=request_not_found');
}

// Get equipment details
$equipment = get_equipment($request['equipment_id']);

// Get user details
$user = get_user($request['user_id']);

// Page title
$page_title = "Print Request #" . $request_id;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            padding: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
        }
        .request-id {
            font-size: 18px;
            margin-top: 10px;
        }
        .section {
            margin-bottom: 20px;
        }
        .section-title {
            font-weight: bold;
            border-bottom: 1px solid #ddd;
            padding-bottom: 5px;
            margin-bottom: 10px;
        }
        .info-row {
            display: flex;
            margin-bottom: 5px;
        }
        .info-label {
            font-weight: bold;
            width: 200px;
        }
        .status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 4px;
            font-weight: bold;
            color: white;
        }
        .status-pending { background-color: #ffc107; }
        .status-approved { background-color: #28a745; }
        .status-rejected { background-color: #dc3545; }
        .status-returned { background-color: #17a2b8; }
        .footer {
            margin-top: 50px;
            text-align: center;
            font-size: 12px;
            color: #666;
        }
        .signature {
            margin-top: 100px;
            display: flex;
            justify-content: space-between;
        }
        .signature-line {
            width: 200px;
            border-top: 1px solid #333;
            margin-top: 5px;
            text-align: center;
        }
        @media print {
            .no-print {
                display: none;
            }
            body {
                padding: 0;
                margin: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo"><?php echo SITE_NAME; ?></div>
            <div>Sports Equipment Management System</div>
            <div class="request-id">Equipment Request #<?php echo $request_id; ?></div>
        </div>
        
        <div class="section">
            <div class="section-title">Request Status</div>
            <div class="info-row">
                <div class="info-label">Status:</div>
                <div>
                    <span class="status status-<?php echo $request['status']; ?>">
                        <?php echo ucfirst($request['status']); ?>
                    </span>
                </div>
            </div>
            <div class="info-row">
                <div class="info-label">Request Date:</div>
                <div><?php echo date('F j, Y, g:i a', strtotime($request['request_date'])); ?></div>
            </div>
            <?php if (isset($request['approval_date']) && !empty($request['approval_date'])): ?>
            <div class="info-row">
                <div class="info-label">Approval Date:</div>
                <div><?php echo date('F j, Y, g:i a', strtotime($request['approval_date'])); ?></div>
            </div>
            <?php endif; ?>
            <div class="info-row">
                <div class="info-label">Expected Return Date:</div>
                <div><?php echo date('F j, Y', strtotime($request['expected_return_date'])); ?></div>
            </div>
            <?php if (isset($request['return_date']) && !empty($request['return_date'])): ?>
            <div class="info-row">
                <div class="info-label">Actual Return Date:</div>
                <div><?php echo date('F j, Y, g:i a', strtotime($request['return_date'])); ?></div>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="section">
            <div class="section-title">Equipment Details</div>
            <div class="info-row">
                <div class="info-label">Name:</div>
                <div><?php echo htmlspecialchars($equipment['name']); ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Category:</div>
                <div><?php echo htmlspecialchars(get_category_name($equipment['category_id'])); ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Quantity Requested:</div>
                <div><?php echo $request['quantity']; ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Current Availability:</div>
                <div><?php echo $equipment['available']; ?> / <?php echo $equipment['quantity']; ?></div>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title">Requester Information</div>
            <div class="info-row">
                <div class="info-label">Name:</div>
                <div>
                    <?php 
                    $fullName = '';
                    if (isset($user['first_name'])) {
                        $fullName .= htmlspecialchars($user['first_name']);
                    }
                    if (isset($user['last_name'])) {
                        $fullName .= ' ' . htmlspecialchars($user['last_name']);
                    }
                    echo !empty(trim($fullName)) ? $fullName : htmlspecialchars($user['username']); 
                    ?>
                </div>
            </div>
            <div class="info-row">
                <div class="info-label">Username:</div>
                <div><?php echo htmlspecialchars($user['username']); ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Email:</div>
                <div><?php echo htmlspecialchars($user['email']); ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Role:</div>
                <div><?php echo ucfirst($user['role']); ?></div>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title">Additional Information</div>
            <div class="info-row">
                <div class="info-label">Purpose:</div>
                <div><?php echo isset($request['purpose']) ? htmlspecialchars($request['purpose']) : 'No purpose provided'; ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Notes:</div>
                <div><?php echo !empty($request['notes']) ? htmlspecialchars($request['notes']) : 'No notes provided'; ?></div>
            </div>
        </div>
        
        <div class="signature">
            <div>
                <div class="signature-line">Requester Signature</div>
            </div>
            <div>
                <div class="signature-line">Authorized By</div>
            </div>
        </div>
        
        <div class="footer">
            <p>This document was generated on <?php echo date('F j, Y, g:i a'); ?></p>
            <p><?php echo SITE_NAME; ?> - Sports Equipment Management System</p>
        </div>
        
        <div class="mt-4 text-center no-print">
            <button class="btn btn-primary" onclick="window.print()">Print</button>
            <a href="request_details.php?id=<?php echo $request_id; ?>" class="btn btn-secondary">Back to Details</a>
        </div>
    </div>
    
    <script>
        // Auto-print when page loads
        window.onload = function() {
            // Slight delay to ensure everything is loaded
            setTimeout(function() {
                // Uncomment the line below to automatically open print dialog
                // window.print();
            }, 500);
        };
    </script>
</body>
</html>