<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and is an admin
check_auth();
check_admin();

$page_title = "Notifications";

// Get notifications for the admin
$notifications = get_user_notifications($_SESSION['user_id']);

// Mark notifications as read
$sql = "UPDATE notifications SET is_read = 1 WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once 'includes/header.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-2">
                <?php include_once 'includes/sidebar.php'; ?>
            </div>
            <div class="col-md-10">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-bell me-2"></i> Notifications</h2>
                </div>
                
                <?php if (empty($notifications)): ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i> No notifications found.
                    </div>
                <?php else: ?>
                    <div class="list-group">
                        <?php foreach ($notifications as $notification): ?>
                            <div class="list-group-item list-group-item-action">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <?php
                                        $icon = 'info-circle';
                                        switch ($notification['type']) {
                                            case 'overdue':
                                                $icon = 'clock';
                                                break;
                                            case 'low_stock':
                                                $icon = 'exclamation-triangle';
                                                break;
                                            case 'request_update':
                                                $icon = 'clipboard-check';
                                                break;
                                        }
                                        ?>
                                        <i class="fas fa-<?php echo $icon; ?> me-2"></i>
                                        <?php echo htmlspecialchars($notification['message']); ?>
                                    </div>
                                    <small class="text-muted">
                                        <?php echo time_elapsed_string($notification['created_at']); ?>
                                    </small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>