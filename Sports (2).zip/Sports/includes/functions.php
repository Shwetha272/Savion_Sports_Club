<?php
require_once 'config.php';

// Function to sanitize input data
function sanitize_input($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    if ($conn) {
        $data = mysqli_real_escape_string($conn, $data);
    }
    return $data;
}

// Function to redirect to a specific page
function redirect($url) {
    header("Location: $url");
    exit;
}

// Function to check if user is logged in
function is_logged_in() {
    return isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;
}

// Function to check if user has a specific role
function has_role($role) {
    return is_logged_in() && isset($_SESSION['role']) && $_SESSION['role'] === $role;
}

// Function to get user by ID
function get_user($user_id) {
    global $conn;
    $sql = "SELECT * FROM users WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_assoc($result);
}

// Function to get equipment by ID
function get_equipment($equipment_id) {
    global $conn;
    $sql = "SELECT * FROM equipment WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $equipment_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_assoc($result);
}

// Function to get all equipment
function get_all_equipment() {
    global $conn;
    $sql = "SELECT * FROM equipment ORDER BY name ASC";
    $result = mysqli_query($conn, $sql);
    $equipment = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $equipment[] = $row;
    }
    return $equipment;
}

// Function to get user requests
function get_user_requests($user_id) {
    global $conn;
    $sql = "SELECT er.*, e.name as equipment_name 
            FROM equipment_requests er 
            JOIN equipment e ON er.equipment_id = e.id 
            WHERE er.user_id = ? 
            ORDER BY er.request_date DESC";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $requests = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $requests[] = $row;
    }
    return $requests;
}

// Function to get user requests with status filter
function get_user_requests_with_filter($user_id, $status = '') {
    global $conn;
    
    if (!empty($status)) {
        $sql = "SELECT er.*, e.name as equipment_name 
                FROM equipment_requests er 
                JOIN equipment e ON er.equipment_id = e.id 
                WHERE er.user_id = ? AND er.status = ?
                ORDER BY er.request_date DESC";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "is", $user_id, $status);
    } else {
        $sql = "SELECT er.*, e.name as equipment_name 
                FROM equipment_requests er 
                JOIN equipment e ON er.equipment_id = e.id 
                WHERE er.user_id = ? 
                ORDER BY er.request_date DESC";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $user_id);
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $requests = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $requests[] = $row;
    }
    return $requests;
}

// Function to get all pending requests
function get_pending_requests() {
    global $conn;
    $sql = "SELECT er.*, e.name as equipment_name, u.username 
            FROM equipment_requests er 
            JOIN equipment e ON er.equipment_id = e.id 
            JOIN users u ON er.user_id = u.id 
            WHERE er.status = 'pending' 
            ORDER BY er.request_date ASC";
    $result = mysqli_query($conn, $sql);
    $requests = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $requests[] = $row;
    }
    return $requests;
}

// Function to update equipment status based on quantity
function update_equipment_status($equipment_id) {
    global $conn;
    $equipment = get_equipment($equipment_id);
    
    if ($equipment['available'] <= 0) {
        $status = 'out_of_stock';
    } elseif ($equipment['available'] < ($equipment['quantity'] * 0.2)) {
        $status = 'low_stock';
    } else {
        $status = 'available';
    }
    
    $sql = "UPDATE equipment SET status = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "si", $status, $equipment_id);
    mysqli_stmt_execute($stmt);
    
    // Create notification if low stock
    if ($status == 'low_stock' || $status == 'out_of_stock') {
        $message = $status == 'low_stock' 
            ? "Equipment '{$equipment['name']}' is running low on stock." 
            : "Equipment '{$equipment['name']}' is out of stock.";
        
        create_admin_notification($message, $status == 'low_stock' ? 'low_stock' : 'general');
    }
}

// Function to create notification for admin
function create_admin_notification($message, $type = 'general') {
    global $conn;
    
    // Check if the tables exist before proceeding
    $table_exists = mysqli_query($conn, "SHOW TABLES LIKE 'notifications'");
    if (mysqli_num_rows($table_exists) == 0) {
        // Table doesn't exist yet, so just return without doing anything
        return;
    }
    
    $sql = "SELECT id FROM users WHERE role = 'admin'";
    $result = mysqli_query($conn, $sql);
    
    while ($row = mysqli_fetch_assoc($result)) {
        $sql = "INSERT INTO notifications (user_id, message, type) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "iss", $row['id'], $message, $type);
        mysqli_stmt_execute($stmt);
    }
}

// Function to create notification for user
function create_user_notification($user_id, $message, $type = 'general') {
    global $conn;
    
    // Check if the tables exist before proceeding
    $table_exists = mysqli_query($conn, "SHOW TABLES LIKE 'notifications'");
    if (mysqli_num_rows($table_exists) == 0) {
        // Table doesn't exist yet, so just return without doing anything
        return;
    }
    
    $sql = "INSERT INTO notifications (user_id, message, type) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "iss", $user_id, $message, $type);
    mysqli_stmt_execute($stmt);
}

// Function to get user notifications
function get_user_notifications($user_id, $limit = 10) {
    global $conn;
    $sql = "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $user_id, $limit);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $notifications = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $notifications[] = $row;
    }
    return $notifications;
}

// Function to count unread notifications
function count_unread_notifications($user_id) {
    global $conn;
    $sql = "SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    return $row['count'];
}

// Function to check for overdue equipment
function check_overdue_equipment() {
    global $conn;
    
    // Check if the table exists before proceeding
    $table_exists = mysqli_query($conn, "SHOW TABLES LIKE 'equipment_requests'");
    if (mysqli_num_rows($table_exists) == 0) {
        // Table doesn't exist yet, so just return without doing anything
        return;
    }
    
    $today = date('Y-m-d');
    $sql = "UPDATE equipment_requests 
            SET status = 'overdue' 
            WHERE status = 'approved' 
            AND expected_return_date < ? 
            AND actual_return_date IS NULL";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $today);
    mysqli_stmt_execute($stmt);
    
    // Create notifications for overdue equipment
    $sql = "SELECT er.*, e.name as equipment_name, u.id as user_id 
            FROM equipment_requests er 
            JOIN equipment e ON er.equipment_id = e.id 
            JOIN users u ON er.user_id = u.id 
            WHERE er.status = 'overdue' 
            AND er.expected_return_date < ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $today);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    while ($row = mysqli_fetch_assoc($result)) {
        $message = "Your equipment '{$row['equipment_name']}' is overdue. Please return it as soon as possible.";
        create_user_notification($row['user_id'], $message, 'overdue');
    }
}

// Function to count total equipment
function count_total_equipment() {
    global $conn;
    $sql = "SELECT COUNT(*) as total FROM equipment";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row['total'] ?? 0;
}
/**
 * Request to return equipment
 * 
 * @param int $request_id The ID of the request
 * @param string $condition The condition of the returned equipment
 * @param string $notes Optional notes about the return
 * @return bool True if successful, false otherwise
 */
function request_return($request_id, $condition, $notes = '') {
    global $conn;
    
    // Update the request status to 'return_requested'
    $sql = "UPDATE equipment_requests SET status = 'return_requested'";
    
    // Check if return_condition column exists
    $check_column = mysqli_query($conn, "SHOW COLUMNS FROM equipment_requests LIKE 'return_condition'");
    if (mysqli_num_rows($check_column) > 0) {
        $sql .= ", return_condition = ?, 
                  return_notes = ?,
                  return_request_date = NOW()
                  WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssi", $condition, $notes, $request_id);
    } else {
        // If columns don't exist, just update the status
        $sql .= " WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $request_id);
    }
    
    if (mysqli_stmt_execute($stmt)) {
        // Get the request details
        $request = get_request($request_id);
        
        // Create notification for admin if the function exists
        $user = get_user($request['user_id']);
        $equipment = get_equipment($request['equipment_id']);
        $message = "User {$user['username']} has requested to return {$equipment['name']}.";
        create_admin_notification($message, 'return_requested');
        
        return true;
    }
    
    return false;
}
/**
 * Count available equipment in the system
 * @return int Number of available equipment
 */
function count_available_equipment() {
    global $conn;
    $sql = "SELECT COUNT(*) as total FROM equipment WHERE available = 1 AND quantity > 0";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row['total'] ?? 0;
}

/**
 * Count total equipment requests
 * @return int Total number of equipment requests
 */
function count_total_requests() {
    global $conn;
    $sql = "SELECT COUNT(*) as total FROM equipment_requests";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row['total'] ?? 0;
}

/**
 * Count pending equipment requests
 * @return int Number of pending equipment requests
 */
function count_pending_requests() {
    global $conn;
    $sql = "SELECT COUNT(*) as total FROM equipment_requests WHERE status = 'pending'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row['total'] ?? 0;
}

/**
 * Count approved equipment requests
 * @return int Number of approved equipment requests
 */
function count_approved_requests() {
    global $conn;
    $sql = "SELECT COUNT(*) as total FROM equipment_requests WHERE status = 'approved'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row['total'] ?? 0;
}

/**
 * Count overdue equipment requests
 * @return int Number of overdue equipment requests
 */
function count_overdue_requests() {
    global $conn;
    $sql = "SELECT COUNT(*) as total FROM equipment_requests 
            WHERE status = 'approved' 
            AND expected_return_date < CURDATE() 
            AND actual_return_date IS NULL";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row['total'] ?? 0;
}

/**
 * Count total users in the system
 * @return int Total number of users
 */
function count_total_users() {
    global $conn;
    $sql = "SELECT COUNT(*) as total FROM users";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row['total'] ?? 0;
}

/**
 * Get recent equipment requests
 * @param int $limit Number of requests to retrieve
 * @return array Array of recent equipment requests
 */
function get_recent_requests($limit = 5) {
    global $conn;
    $sql = "SELECT er.*, u.username, e.name as equipment_name 
            FROM equipment_requests er
            JOIN users u ON er.user_id = u.id
            JOIN equipment e ON er.equipment_id = e.id
            ORDER BY er.request_date DESC
            LIMIT ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $limit);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $requests = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $requests[] = $row;
    }
    
    return $requests;
}

/**
 * Get recent users who joined the system
 * @param int $limit Number of users to retrieve
 * @return array Array of recent users
 */
function get_recent_users($limit = 5) {
    global $conn;
    $sql = "SELECT * FROM users ORDER BY created_at DESC LIMIT ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $limit);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $users = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $users[] = $row;
    }
    
    return $users;
}

/**
 * Get equipment with low stock
 * @param int $threshold Stock threshold to consider as low
 * @return array Array of equipment with low stock
 */
function get_low_stock_equipment($threshold = 3) {
    global $conn;
    $sql = "SELECT * FROM equipment WHERE quantity <= ? ORDER BY quantity ASC";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $threshold);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $equipment = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $equipment[] = $row;
    }
    
    return $equipment;
}
/**
 * Get overdue equipment
 * @return array Array of overdue equipment
 */
function get_overdue_equipment() {
    global $conn;
    $sql = "SELECT er.*, u.username, e.name as equipment_name 
            FROM equipment_requests er
            JOIN users u ON er.user_id = u.id
            JOIN equipment e ON er.equipment_id = e.id
            WHERE er.status = 'approved' 
            AND er.expected_return_date < CURDATE() 
            AND er.actual_return_date IS NULL
            ORDER BY er.expected_return_date ASC";
    
    $result = mysqli_query($conn, $sql);
    
    $overdue = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $overdue[] = $row;
    }
    
    return $overdue;
}
/**
 * Get overdue requests
 * @return array Array of overdue equipment requests
 */
function get_overdue_requests() {
    global $conn;
    $sql = "SELECT er.*, u.username, e.name as equipment_name 
            FROM equipment_requests er
            JOIN users u ON er.user_id = u.id
            JOIN equipment e ON er.equipment_id = e.id
            WHERE er.status = 'approved' 
            AND er.expected_return_date < CURDATE() 
            AND er.actual_return_date IS NULL
            ORDER BY er.expected_return_date ASC";
    
    $result = mysqli_query($conn, $sql);
    
    $overdue = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $overdue[] = $row;
    }
    
    return $overdue;
}
/**
 * Get request by ID
 * 
 * @param int $request_id The request ID
 * @return array|false The request data or false if not found
 */
function get_request_by_id($request_id) {
    global $conn;
    
    $sql = "SELECT * FROM equipment_requests WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $request_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($result && mysqli_num_rows($result) > 0) {
        return mysqli_fetch_assoc($result);
    }
    
    return false;
}

/**
 * Update request status
 * 
 * @param int $request_id The request ID
 * @param string $status The new status
 * @param string $notes Any notes to add
 * @return bool True on success, false on failure
 */
function update_request_status($request_id, $status, $notes = '') {
    global $conn;
    
    // Check if approval_date column exists
    $check_approval_column = mysqli_query($conn, "SHOW COLUMNS FROM equipment_requests LIKE 'approval_date'");
    $has_approval_column = mysqli_num_rows($check_approval_column) > 0;
    
    // Check if actual_return_date column exists
    $check_return_column = mysqli_query($conn, "SHOW COLUMNS FROM equipment_requests LIKE 'actual_return_date'");
    $has_return_column = mysqli_num_rows($check_return_column) > 0;
    
    $current_date = date('Y-m-d H:i:s');
    $sql = "UPDATE equipment_requests SET status = ?";
    
    // Add notes if provided
    if (!empty($notes)) {
        $sql .= ", notes = ?";
    }
    
    // Add approval_date if status is approved and column exists
    if ($status === 'approved' && $has_approval_column) {
        $sql .= ", approval_date = ?";
    }
    
    // Add return_date if status is returned and column exists
    if ($status === 'returned' && $has_return_column) {
        $sql .= ", actual_return_date = ?";
    }
    
    $sql .= " WHERE id = ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    
    if ($status === 'approved' && $has_approval_column && !empty($notes)) {
        mysqli_stmt_bind_param($stmt, "sssi", $status, $notes, $current_date, $request_id);
    } elseif ($status === 'returned' && $has_return_column && !empty($notes)) {
        mysqli_stmt_bind_param($stmt, "sssi", $status, $notes, $current_date, $request_id);
    } elseif (!empty($notes)) {
        mysqli_stmt_bind_param($stmt, "ssi", $status, $notes, $request_id);
    } else {
        mysqli_stmt_bind_param($stmt, "si", $status, $request_id);
    }
    
    $result = mysqli_stmt_execute($stmt);
    
    // If status is approved, update equipment availability
    if ($status === 'approved' && $result) {
        $request = get_request_by_id($request_id);
        if ($request) {
            $equipment = get_equipment($request['equipment_id']);
            if ($equipment) {
                // Update available quantity
                $new_available = $equipment['available'] - $request['quantity'];
                $sql = "UPDATE equipment SET available = ? WHERE id = ?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "ii", $new_available, $request['equipment_id']);
                mysqli_stmt_execute($stmt);
            }
        }
    }
    
    return $result;
}
/**
 * Update equipment availability
 * 
 * @param int $equipment_id The equipment ID
 * @param int $quantity_change The change in quantity (positive or negative)
 * @return bool True on success, false on failure
 */
function update_equipment_availability($equipment_id, $quantity_change) {
    global $conn;
    
    // Get current equipment data
    $equipment = get_equipment($equipment_id);
    if (!$equipment) {
        return false;
    }
    
    // Calculate new available quantity
    $new_available = $equipment['available'] + $quantity_change;
    
    // Make sure available doesn't exceed total quantity or go below zero
    $new_available = max(0, min($new_available, $equipment['quantity']));
    
    // Update the equipment
    $sql = "UPDATE equipment SET available = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $new_available, $equipment_id);
    
    return mysqli_stmt_execute($stmt);
}

// Function to get admin notifications


// Function to get admin notifications
function get_admin_notifications($limit = 0) {
    global $conn;
    
    $sql = "SELECT * FROM notifications WHERE user_id = 0 OR user_id IS NULL ORDER BY created_at DESC";
    
    if ($limit > 0) {
        $sql .= " LIMIT ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $limit);
    } else {
        $stmt = mysqli_prepare($conn, $sql);
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $notifications = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $notifications[] = $row;
    }
    return $notifications;
}

// Function to count unread admin notifications
function count_admin_notifications() {
    global $conn;
    $sql = "SELECT COUNT(*) as count FROM notifications WHERE (user_id = 0 OR user_id IS NULL) AND is_read = 0";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row['count'];
}

// Function to get system alerts
function get_system_alerts() {
    global $conn;
    
    // Check if the table exists before proceeding
    $table_exists = mysqli_query($conn, "SHOW TABLES LIKE 'system_alerts'");
    if (mysqli_num_rows($table_exists) == 0) {
        // Table doesn't exist yet, so return an empty array
        return [];
    }
    
    $sql = "SELECT * FROM system_alerts WHERE active = 1 ORDER BY priority DESC";
    $result = mysqli_query($conn, $sql);
    $alerts = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $alerts[] = $row;
    }
    return $alerts;
}

// Function to get user's borrowing history
function get_user_borrowing_history($user_id, $limit = 0) {
    global $conn;
    
    $sql = "SELECT er.*, e.name as equipment_name 
            FROM equipment_requests er 
            JOIN equipment e ON er.equipment_id = e.id 
            WHERE er.user_id = ? AND (er.status = 'returned' OR er.status = 'approved' OR er.status = 'overdue')
            ORDER BY er.request_date DESC";
    
    if ($limit > 0) {
        $sql .= " LIMIT ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ii", $user_id, $limit);
    } else {
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $user_id);
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $history = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $history[] = $row;
    }
    return $history;
}

/**
 * Get all equipment categories
 * 
 * @return array Array of equipment categories
 */
function get_equipment_categories() {
    global $conn;
    
    $categories = [];
    
    // Check if the category column exists in the equipment table
    $check_column = mysqli_query($conn, "SHOW COLUMNS FROM equipment LIKE 'category'");
    
    if (mysqli_num_rows($check_column) > 0) {
        // Column exists, get distinct categories
        $sql = "SELECT DISTINCT category FROM equipment WHERE category IS NOT NULL AND category != '' ORDER BY category";
        $result = mysqli_query($conn, $sql);
        
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $categories[] = $row['category'];
            }
        }
    }
    
    // If no categories found in database, return default categories
    if (empty($categories)) {
        $categories = [
            'Ball Sports',
            'Racket Sports',
            'Fitness Equipment',
            'Outdoor Sports',
            'Indoor Sports',
            'Water Sports',
            'Team Sports',
            'Individual Sports',
            'Training Equipment',
            'Protective Gear'
        ];
    }
    
    return $categories;
}
/**
 * Get equipment categories
 * 
 * @return array Array of equipment categories
 */

/**
 * Get category name by ID
 * 
 * @param int $category_id The ID of the category
 * @return string The name of the category
 */
function get_category_name($category_id) {
    global $conn;
     // Check if the categories table exists
     $table_exists = mysqli_query($conn, "SHOW TABLES LIKE 'categories'");
     if (mysqli_num_rows($table_exists) == 0) {
         // Table doesn't exist, return a default value
         return 'Uncategorized';
     }
     
     // If category_id is 0 or null, return 'Uncategorized'
     if (!$category_id) {
         return 'Uncategorized';
     }
    $sql = "SELECT name FROM categories WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $category_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        return $row['name'];
    }
    
    return 'Unknown Category';
}

/**
 * Get a specific equipment request by ID
 * 
 * @param int $request_id The ID of the request to retrieve
 * @return array|false The request data or false if not found
 */
function get_request($request_id) {
    global $conn;
    $sql = "SELECT * FROM equipment_requests WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $request_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_assoc($result);
}

// REMOVE THE DUPLICATE FUNCTION DECLARATION HERE (around line 671)
// /**
//  * Get a specific equipment request by ID
//  * 
//  * @param int $request_id The ID of the request to retrieve
//  * @return array|false The request data or false if not found
//  */
// function get_request($request_id) {
//     global $conn;
//     $sql = "SELECT * FROM equipment_requests WHERE id = ?";
//     $stmt = mysqli_prepare($conn, $sql);
//     mysqli_stmt_bind_param($stmt, "i", $request_id);
//     mysqli_stmt_execute($stmt);
//     $result = mysqli_stmt_get_result($stmt);
//     return mysqli_fetch_assoc($result);
// }

/**
 * Get all equipment requests with optional status filter
 * 
 * @param string $status Optional status filter
 * @return array Array of equipment requests
 */
function get_all_requests($status = '') {
    global $conn;
    
    if (!empty($status)) {
        $sql = "SELECT er.*, e.name as equipment_name, u.username 
                FROM equipment_requests er 
                JOIN equipment e ON er.equipment_id = e.id 
                JOIN users u ON er.user_id = u.id 
                WHERE er.status = ? 
                ORDER BY er.request_date DESC";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $status);
    } else {
        $sql = "SELECT er.*, e.name as equipment_name, u.username 
                FROM equipment_requests er 
                JOIN equipment e ON er.equipment_id = e.id 
                JOIN users u ON er.user_id = u.id 
                ORDER BY er.request_date DESC";
        $stmt = mysqli_prepare($conn, $sql);
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $requests = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $requests[] = $row;
    }
    
    return $requests;
}

/**
 * Approve an equipment request
 * 
 * @param int $request_id The ID of the request to approve
 * @param string $expected_return_date The expected return date
 * @return bool True if successful, false otherwise
 */
function approve_request($request_id, $expected_return_date) {
    global $conn;
    $sql = "UPDATE equipment_requests 
            SET status = 'approved',  
                expected_return_date = ?
            WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "si", $expected_return_date, $request_id);
    
    if (mysqli_stmt_execute($stmt)) {
        // Get the request details to update equipment availability
        $request = get_request($request_id);
        if ($request) {
            // Get the equipment
            $equipment = get_equipment($request['equipment_id']);
            if ($equipment) {
                // Update available quantity
                $new_available = $equipment['available'] - $request['quantity'];
                $sql = "UPDATE equipment SET available = ? WHERE id = ?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "ii", $new_available, $request['equipment_id']);
                mysqli_stmt_execute($stmt);
                
                // Create notification for the user
                $message = "Your equipment request has been approved.";
                create_user_notification($request['user_id'], $message, 'request_approved');
            }
        }
        return true;
    }
    return false;
}

/**
 * Reject an equipment request
 * 
 * @param int $request_id The ID of the request to reject
 * @param string $rejection_reason Optional reason for rejection
 * @return bool True if successful, false otherwise
 */
function reject_request($request_id, $rejection_reason = '') {
    global $conn;
    $sql = "UPDATE equipment_requests 
            SET status = 'rejected', 
                rejection_date = NOW(), 
                rejection_reason = ?, 
                admin_id = ? 
            WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    $admin_id = $_SESSION['id'];
    mysqli_stmt_bind_param($stmt, "sii", $rejection_reason, $admin_id, $request_id);
    return mysqli_stmt_execute($stmt);
}

/**
 * Mark an equipment request as returned
 * 
 * @param int $request_id The ID of the request to mark as returned
 * @param string $condition The condition of the returned equipment
 * @param string $notes Optional notes about the return
 * @return bool True if successful, false otherwise
 */
function mark_returned($request_id, $condition, $notes = '') {
    global $conn;
    $sql = "UPDATE equipment_requests 
            SET status = 'returned', 
                actual_return_date = NOW(), 
                return_condition = ?, 
                return_notes = ? 
            WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssi", $condition, $notes, $request_id);
    return mysqli_stmt_execute($stmt);
}

/**
 * Update equipment quantity
 * 
 * @param int $equipment_id The ID of the equipment to update
 * @param int $new_quantity The new quantity value
 * @return bool True if successful, false otherwise
 */
function update_equipment_quantity($equipment_id, $new_quantity) {
    global $conn;
    $sql = "UPDATE equipment SET quantity = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $new_quantity, $equipment_id);
    return mysqli_stmt_execute($stmt);
}

/**
 * Add new equipment to the database
 * 
 * @param string $name Equipment name
 * @param int $category_id Category ID
 * @param string $description Equipment description
 * @param int $quantity Total quantity
 * @param string $condition Equipment condition
 * @param string $location Storage location
 * @param string $image Image filename
 * @return bool True on success, false on failure
 */
function add_equipment($name, $category_id, $description, $quantity, $condition, $location, $image = '') {
    global $conn;
    
    // Sanitize inputs
    $name = mysqli_real_escape_string($conn, $name);
    $description = mysqli_real_escape_string($conn, $description);
    $condition = mysqli_real_escape_string($conn, $condition);
    $location = mysqli_real_escape_string($conn, $location);
    $image = mysqli_real_escape_string($conn, $image);
    
    // Convert to integers
    $category_id = (int)$category_id;
    $quantity = (int)$quantity;
    
    // Set available quantity equal to total quantity for new equipment
    $available = $quantity;
    
    // Current timestamp
    $date_added = date('Y-m-d H:i:s');
    
    // Insert equipment into database
    $sql = "INSERT INTO equipment (name, category_id, description, quantity, available, 
            condition_status, location, image, date_added) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sisiissss", $name, $category_id, $description, $quantity, 
                          $available, $condition, $location, $image, $date_added);
    
    $result = mysqli_stmt_execute($stmt);
    
    if ($result) {
        // Get the ID of the newly inserted equipment
        $equipment_id = mysqli_insert_id($conn);
        
        // Log the activity
        log_activity($_SESSION['id'], 'Added new equipment: ' . $name, 'equipment', $equipment_id);
        
        return $equipment_id;
    }
    
    return false;
}

/**
 * Count the number of pending equipment requests for a specific user
 * 
 * @param int $user_id User ID
 * @return int Number of pending requests
 */
function count_user_pending_requests($user_id) {
    global $conn;
    
    $sql = "SELECT COUNT(*) as pending_count FROM equipment_requests WHERE user_id = ? AND status = 'pending'";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $row = mysqli_fetch_assoc($result);
    return $row['pending_count'];
}

/**
 * Count the number of approved equipment requests for a specific user
 * 
 * @param int $user_id User ID
 * @return int Number of approved requests
 */
function count_user_approved_requests($user_id) {
    global $conn;
    
    $sql = "SELECT COUNT(*) as approved_count FROM equipment_requests WHERE user_id = ? AND status = 'approved'";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $row = mysqli_fetch_assoc($result);
    return $row['approved_count'];
}

/**
 * Count the number of overdue equipment requests for a specific user
 * 
 * @param int $user_id User ID
 * @return int Number of overdue requests
 */
function count_user_overdue_requests($user_id) {
    global $conn;
    
    $sql = "SELECT COUNT(*) as overdue_count FROM equipment_requests 
            WHERE user_id = ? AND status = 'approved' 
            AND expected_return_date < CURDATE() 
            AND actual_return_date IS NULL";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $row = mysqli_fetch_assoc($result);
    return $row['overdue_count'];
}

/**
 * Log user activity in the system
 * 
 * @param int $user_id The ID of the user performing the action
 * @param string $action Description of the action performed
 * @param string $entity The entity affected by the action (e.g., 'equipment')
 * @param int $entity_id The ID of the entity affected
 * @return bool True if the log was successful, false otherwise
 */
function log_activity($user_id, $action, $entity, $entity_id) {
    global $conn;
    
    $sql = "INSERT INTO activity_log (user_id, action, entity, entity_id, log_date) 
            VALUES (?, ?, ?, ?, NOW())";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "issi", $user_id, $action, $entity, $entity_id);
    
    return mysqli_stmt_execute($stmt);
}

/**
 * Update equipment details in the database
 * 
 * @param int $equipment_id The ID of the equipment to update
 * @param string $name Equipment name
 * @param string $description Equipment description
 * @param int $quantity Total quantity
 * @param string $condition Equipment condition
 * @param string $location Storage location
 * @param string $image Image filename
 * @return bool True on success, false on failure
 */
function update_equipment($equipment_id, $name, $description, $quantity, $condition, $location, $image = '') {
    global $conn;
    
    // Sanitize inputs
    $name = mysqli_real_escape_string($conn, $name);
    $description = mysqli_real_escape_string($conn, $description);
    $condition = mysqli_real_escape_string($conn, $condition);
    $location = mysqli_real_escape_string($conn, $location);
    $image = mysqli_real_escape_string($conn, $image);
    
    // Convert to integers
    $equipment_id = (int)$equipment_id;
    $quantity = (int)$quantity;
    
    // Update equipment in database
    $sql = "UPDATE equipment SET name = ?, description = ?, quantity = ?, condition_status = ?, location = ?, image = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssiissi", $name, $description, $quantity, $condition, $location, $image, $equipment_id);
    
    return mysqli_stmt_execute($stmt);
}

/**
 * Delete equipment from the database
 * 
 * @param int $equipment_id The ID of the equipment to delete
 * @return bool True on success, false on failure
 */
function delete_equipment($equipment_id) {
    global $conn;
    
    // Convert to integer
    $equipment_id = (int)$equipment_id;
    
    // Delete equipment from database
    $sql = "DELETE FROM equipment WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $equipment_id);
    
    return mysqli_stmt_execute($stmt);
}

/**
 * Returns a human-readable time difference (e.g., "2 hours ago")
 * 
 * @param string $datetime The date/time string to convert
 * @param bool $full Whether to show the full time difference or just the most significant part
 * @return string Human-readable time difference
 */
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    // Calculate weeks without using dynamic property
    $weeks = floor($diff->d / 7);
    $days_remainder = $diff->d % 7;

    $string = array();
    
    // Build the time parts array
    if ($diff->y > 0) {
        $string['y'] = $diff->y . ' year' . ($diff->y > 1 ? 's' : '');
    }
    if ($diff->m > 0) {
        $string['m'] = $diff->m . ' month' . ($diff->m > 1 ? 's' : '');
    }
    if ($weeks > 0) {
        $string['w'] = $weeks . ' week' . ($weeks > 1 ? 's' : '');
    }
    if ($days_remainder > 0) {
        $string['d'] = $days_remainder . ' day' . ($days_remainder > 1 ? 's' : '');
    }
    if ($diff->h > 0) {
        $string['h'] = $diff->h . ' hour' . ($diff->h > 1 ? 's' : '');
    }
    if ($diff->i > 0) {
        $string['i'] = $diff->i . ' minute' . ($diff->i > 1 ? 's' : '');
    }
    if ($diff->s > 0) {
        $string['s'] = $diff->s . ' second' . ($diff->s > 1 ? 's' : '');
    }

    if (!$full) {
        $string = array_slice($string, 0, 1);
    }
    
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}

/**
 * Set a message to be displayed to the user
 * 
 * @param string $type The type of message (success, error, warning, info)
 * @param string $message The message text
 * @return void
 */
function set_message($type, $message) {
    if (!isset($_SESSION['messages'])) {
        $_SESSION['messages'] = [];
    }
    
    $_SESSION['messages'][] = [
        'type' => $type,
        'text' => $message
    ];
}

/**
 * Display all messages to the user and clear them from the session
 * 
 * @return string HTML for displaying messages
 */
function display_messages() {
    $output = '';
    
    if (isset($_SESSION['messages']) && !empty($_SESSION['messages'])) {
        foreach ($_SESSION['messages'] as $message) {
            $type = $message['type'];
            $text = $message['text'];
            
            // Map message type to Bootstrap alert class
            $alert_class = 'alert-info';
            $icon_class = 'info-circle';
            
            switch ($type) {
                case 'success':
                    $alert_class = 'alert-success';
                    $icon_class = 'check-circle';
                    break;
                case 'error':
                    $alert_class = 'alert-danger';
                    $icon_class = 'exclamation-circle';
                    break;
                case 'warning':
                    $alert_class = 'alert-warning';
                    $icon_class = 'exclamation-triangle';
                    break;
            }
            
            $output .= '<div class="alert ' . $alert_class . ' alert-dismissible fade show" role="alert">';
            $output .= '<i class="fas fa-' . $icon_class . ' me-2"></i>' . $text;
            $output .= '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
            $output .= '</div>';
        }
        
        // Clear messages after displaying them
        $_SESSION['messages'] = [];
    }
    
    return $output;
}
?>