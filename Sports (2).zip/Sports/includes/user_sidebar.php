<div class="card mb-4">
    <div class="card-header bg-primary text-white">
        <h5 class="card-title mb-0">User Menu</h5>
    </div>
    <div class="list-group list-group-flush">
        <a href="dashboard.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
        </a>
        <a href="equipment.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'equipment.php' ? 'active' : ''; ?>">
            <i class="fas fa-volleyball-ball me-2"></i> Browse Equipment
        </a>
        <a href="my_requests.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'my_requests.php' ? 'active' : ''; ?>">
            <i class="fas fa-clipboard-list me-2"></i> My Requests
            <?php $pending_count = count_user_pending_requests($_SESSION['id']); ?>
            <?php if ($pending_count > 0): ?>
                <span class="badge bg-primary float-end"><?php echo $pending_count; ?></span>
            <?php endif; ?>
        </a>
        <a href="history.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'history.php' ? 'active' : ''; ?>">
            <i class="fas fa-history me-2"></i> Borrowing History
        </a>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header bg-info text-white">
        <h5 class="card-title mb-0">Quick Stats</h5>
    </div>
    <div class="card-body">
        <div class="d-flex justify-content-between mb-2">
            <span><i class="fas fa-clock text-warning me-1"></i> Pending:</span>
            <span class="badge bg-warning text-dark"><?php echo count_user_pending_requests($_SESSION['id']); ?></span>
        </div>
        <div class="d-flex justify-content-between mb-2">
            <span><i class="fas fa-check text-success me-1"></i> Approved:</span>
            <span class="badge bg-success"><?php echo count_user_approved_requests($_SESSION['id']); ?></span>
        </div>
        <div class="d-flex justify-content-between">
            <span><i class="fas fa-exclamation-triangle text-danger me-1"></i> Overdue:</span>
            <span class="badge bg-danger"><?php echo count_user_overdue_requests($_SESSION['id']); ?></span>
        </div>
    </div>
</div>