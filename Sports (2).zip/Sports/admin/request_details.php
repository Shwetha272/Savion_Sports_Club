<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and is an admin
if (!is_logged_in() || !has_role('admin')) {
    redirect('../login.php?error=unauthorized');
}

// Get request ID from URL
$request_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// If no valid ID provided, redirect to requests page
if ($request_id <= 0) {
    redirect('requests.php?error=invalid_request');
}

// Get request details
$request = get_request_by_id($request_id);

// If request not found, redirect to requests page
if (!$request) {
    redirect('requests.php?error=request_not_found');
}

// Get equipment details
$equipment = get_equipment($request['equipment_id']);

// Get user details
$user = get_user($request['user_id']);

// Handle request status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $new_status = $_POST['status'];
    $notes = isset($_POST['notes']) ? $_POST['notes'] : '';
    
    // Update request status
    $result = update_request_status($request_id, $new_status, $notes);
    
    if ($result) {
        // If approved, update equipment availability
        if ($new_status === 'approved') {
            update_equipment_availability($request['equipment_id'], -$request['quantity']);
        }
        
        // If returned, update equipment availability
        if ($new_status === 'returned') {
            update_equipment_availability($request['equipment_id'], $request['quantity']);
        }
        
        redirect("request_details.php?id=$request_id&success=status_updated");
    } else {
        redirect("request_details.php?id=$request_id&error=update_failed");
    }
}

// Page title
$page_title = "Request Details";
?>

<!-- Add custom styles for background image -->
<style>
    body {
        position: relative;
        background-color: transparent !important;
    }
    
    body::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: url('../images/sgbit.jpg');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        opacity: 0.2;
        z-index: -1;
    }
</style>

<?php include_once '../includes/header.php'; ?>

<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col">
            <h1 class="h3 mb-0 text-gray-800">
                <i class="fas fa-clipboard-list me-2"></i> Request Details
            </h1>
        </div>
        <div class="col-auto">
            <a href="requests.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i> Back to Requests
            </a>
        </div>
    </div>
    
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-1"></i> 
            <?php echo $_GET['success'] === 'status_updated' ? 'Request status has been updated successfully.' : ''; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-1"></i> 
            <?php echo $_GET['error'] === 'update_failed' ? 'Failed to update request status.' : ''; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Request #<?php echo $request_id; ?></h6>
                    <span class="badge bg-<?php 
                        echo $request['status'] === 'pending' ? 'warning' : 
                            ($request['status'] === 'approved' ? 'success' : 
                                ($request['status'] === 'rejected' ? 'danger' : 
                                    ($request['status'] === 'returned' ? 'info' : 'secondary'))); 
                    ?> text-white">
                        <?php echo ucfirst($request['status']); ?>
                    </span>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5 class="text-muted mb-3">Equipment Details</h5>
                            <p><strong>Name:</strong> <?php echo htmlspecialchars($equipment['name']); ?></p>
                            <p><strong>Category:</strong> <?php echo htmlspecialchars(get_category_name($equipment['category_id'])); ?></p>
                            <p><strong>Quantity Requested:</strong> <?php echo $request['quantity']; ?></p>
                            <p><strong>Current Availability:</strong> <?php echo $equipment['available']; ?> / <?php echo $equipment['quantity']; ?></p>
                        </div>
                        <div class="col-md-6">
                            <h5 class="text-muted mb-3">Requester Information</h5>
                            <p><strong>Name:</strong> <?php 
                                // Check if first_name and last_name exist before trying to display them
                                $fullName = '';
                                if (isset($user['first_name'])) {
                                    $fullName .= htmlspecialchars($user['first_name']);
                                }
                                if (isset($user['last_name'])) {
                                    $fullName .= ' ' . htmlspecialchars($user['last_name']);
                                }
                                // If no name found, display username instead
                                echo !empty(trim($fullName)) ? $fullName : htmlspecialchars($user['username']); 
                            ?></p>
                            <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
                            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                            <p><strong>Role:</strong> <?php echo ucfirst($user['role']); ?></p>
                        </div>
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5 class="text-muted mb-3">Request Timeline</h5>
                            <p><strong>Requested On:</strong> <?php echo date('F j, Y, g:i a', strtotime($request['request_date'])); ?></p>
                            <p><strong>Expected Return:</strong> <?php echo date('F j, Y', strtotime($request['expected_return_date'])); ?></p>
                            <?php if ($request['status'] === 'approved'): ?>
                                <p><strong>Approved On:</strong> <?php echo isset($request['approval_date']) ? date('F j, Y, g:i a', strtotime($request['approval_date'])) : 'N/A'; ?></p>
                            <?php endif; ?>
                            <?php if ($request['status'] === 'returned'): ?>
                                <p><strong>Returned On:</strong> <?php echo isset($request['return_date']) ? date('F j, Y, g:i a', strtotime($request['return_date'])) : 'N/A'; ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <h5 class="text-muted mb-3">Additional Information</h5>
                            <p><strong>Purpose:</strong> <?php echo isset($request['purpose']) ? htmlspecialchars($request['purpose']) : 'No purpose provided'; ?></p>
                            <p><strong>Notes:</strong> <?php echo !empty($request['notes']) ? htmlspecialchars($request['notes']) : 'No notes provided'; ?></p>
                        </div>
                    </div>
                    
                    <?php if ($request['status'] === 'approved' && strtotime($request['expected_return_date']) < time()): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i> This equipment is overdue by 
                            <?php echo floor((time() - strtotime($request['expected_return_date'])) / (60 * 60 * 24)); ?> days.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Update Request Status</h6>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="">Select Status</option>
                                <option value="pending" <?php echo $request['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="approved" <?php echo $request['status'] === 'approved' ? 'selected' : ''; ?>>Approved</option>
                                <option value="rejected" <?php echo $request['status'] === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                                <option value="returned" <?php echo $request['status'] === 'returned' ? 'selected' : ''; ?>>Returned</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="notes" class="form-label">Notes</label>
                            <textarea class="form-control" id="notes" name="notes" rows="3"><?php echo isset($request['notes']) ? htmlspecialchars($request['notes']) : ''; ?></textarea>
                        </div>
                        
                        <button type="submit" name="update_status" class="btn btn-primary w-100">
                            <i class="fas fa-save me-1"></i> Update Status
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Actions</h6>
                </div>
                <div class="card-body">
                    <a href="mailto:<?php echo $user['email']; ?>" class="btn btn-info w-100 mb-2">
                        <i class="fas fa-envelope me-1"></i> Contact Requester
                    </a>
                    
                    <a href="print_request.php?id=<?php echo $request_id; ?>" target="_blank" class="btn btn-secondary w-100">
                        <i class="fas fa-print me-1"></i> Print Request Details
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>