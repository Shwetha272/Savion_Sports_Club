<?php
require_once '../includes/functions.php';
require_once '../includes/config.php';

// Check if user is logged in and is an admin
if (!is_logged_in()) {
    redirect('/Sports/login.php');
}

if (!has_role('admin')) {
    redirect('/Sports/403.php');
}

// Get page title
$page_title = "Settings";
include_once '../includes/header.php';
?>

<head>
    <style>
        body {
            position: relative;
            background-color: transparent !important;
        }
        
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('../images/sgbit.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            opacity: 0.2;
            z-index: -1;
        }
    </style>
</head>

<div class="container py-4">
    <h1 class="mb-4">System Settings</h1>
    
    <?php echo display_messages(); ?>
    
    <div class="card">
        <div class="card-body">
            <form method="POST" action="process_settings.php">
                <div class="mb-3">
                    <label for="site_name" class="form-label">Site Name</label>
                    <input type="text" class="form-control" id="site_name" name="site_name" 
                           value="<?php echo get_setting('site_name', 'Sports Equipment Management'); ?>">
                </div>
                
                <div class="mb-3">
                    <label for="admin_email" class="form-label">Admin Email</label>
                    <input type="email" class="form-control" id="admin_email" name="admin_email" 
                           value="<?php echo get_setting('admin_email', ''); ?>">
                </div>
                
                <div class="mb-3">
                    <label for="items_per_page" class="form-label">Items Per Page</label>
                    <input type="number" class="form-control" id="items_per_page" name="items_per_page" 
                           value="<?php echo get_setting('items_per_page', '10'); ?>">
                </div>
                
                <button type="submit" class="btn btn-primary">Save Settings</button>
            </form>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>