<?php
$page_title = "Equipment Requests";
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and is admin
if (!is_logged_in() || !has_role('admin')) {
    redirect('login.php');
}

// Get admin information
$admin = get_user($_SESSION['id']);

// Handle request actions (approve, reject, return)
$action = isset($_GET['action']) ? $_GET['action'] : '';
$request_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$success_message = '';
$error_message = '';

// Process form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['approve_request'])) {
        // Approve request
        $request_id = intval($_POST['request_id']);
        $expected_return_date = $_POST['expected_return_date'];
        
        // Validate return date
        if (empty($expected_return_date)) {
            $error_message = "Expected return date is required.";
        } elseif (strtotime($expected_return_date) < strtotime(date('Y-m-d'))) {
            $error_message = "Expected return date cannot be in the past.";
        } else {
            // Get request details
            $request = get_request($request_id);
            if ($request) {
                // Check if equipment is available
                $equipment = get_equipment($request['equipment_id']);
                if ($equipment && $equipment['quantity'] > 0) {
                    // Update request status
                    $result = approve_request($request_id, $expected_return_date);
                    if ($result) {
                        // Decrease equipment quantity
                        update_equipment_quantity($request['equipment_id'], $equipment['quantity'] - 1);
                        
                        // Create notification for user
                        $message = "Your request for '{$equipment['name']}' has been approved. Please pick it up from the sports office.";
                        create_user_notification($request['user_id'], $message, 'request_approved');
                        
                        $success_message = "Request approved successfully.";
                        redirect("requests.php?success=" . urlencode($success_message));
                    } else {
                        $error_message = "Failed to approve request.";
                    }
                } else {
                    $error_message = "Equipment is not available.";
                }
            } else {
                $error_message = "Request not found.";
            }
        }
    } elseif (isset($_POST['reject_request'])) {
        // Reject request
        $request_id = intval($_POST['request_id']);
        $rejection_reason = trim($_POST['rejection_reason']);
        
        // Get request details
        $request = get_request($request_id);
        if ($request) {
            // Update request status
            $result = reject_request($request_id, $rejection_reason);
            if ($result) {
                // Create notification for user
                $equipment = get_equipment($request['equipment_id']);
                $message = "Your request for '{$equipment['name']}' has been rejected.";
                if (!empty($rejection_reason)) {
                    $message .= " Reason: $rejection_reason";
                }
                create_user_notification($request['user_id'], $message, 'request_rejected');
                
                $success_message = "Request rejected successfully.";
                redirect("requests.php?success=" . urlencode($success_message));
            } else {
                $error_message = "Failed to reject request.";
            }
        } else {
            $error_message = "Request not found.";
        }
    } elseif (isset($_POST['mark_returned'])) {
        // Mark equipment as returned
        $request_id = intval($_POST['request_id']);
        $condition = trim($_POST['return_condition']);
        $notes = trim($_POST['return_notes']);
        
        // Get request details
        $request = get_request($request_id);
        if ($request) {
            // Update request status
            $result = mark_returned($request_id, $condition, $notes);
            if ($result) {
                // Increase equipment quantity
                $equipment = get_equipment($request['equipment_id']);
                update_equipment_quantity($request['equipment_id'], $equipment['quantity'] + 1);
                
                // Create notification for user
                $message = "Your returned equipment '{$equipment['name']}' has been processed.";
                create_user_notification($request['user_id'], $message, 'equipment_returned');
                
                $success_message = "Equipment marked as returned successfully.";
                redirect("requests.php?success=" . urlencode($success_message));
            } else {
                $error_message = "Failed to mark equipment as returned.";
            }
        } else {
            $error_message = "Request not found.";
        }
    }
}

// Get request data based on action
$request_data = [];
if (in_array($action, ['approve', 'reject', 'return']) && $request_id > 0) {
    $request_data = get_request($request_id);
    if (!$request_data) {
        $error_message = "Request not found.";
        $action = '';
    } else {
        // Get equipment and user details
        $equipment_data = get_equipment($request_data['equipment_id']);
        $user_data = get_user($request_data['user_id']);
        $request_data['equipment_name'] = $equipment_data['name'] ?? 'Unknown';
        $request_data['username'] = $user_data['username'] ?? 'Unknown';
    }
}

// Get all requests for listing with filter
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$all_requests = get_all_requests($status_filter);

// Get success message from URL if redirected
if (isset($_GET['success'])) {
    $success_message = $_GET['success'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once 'includes/header.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-2">
                <?php include_once 'includes/sidebar.php'; ?>
            </div>
            <div class="col-md-10">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-clipboard-list me-2"></i> Equipment Requests</h2>
                </div>
                
                <?php if (!empty($success_message)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-1"></i> <?php echo $success_message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($error_message)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-circle me-1"></i> <?php echo $error_message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($action === 'approve'): ?>
                    <!-- Approve Request Form -->
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="card-title mb-0">Approve Equipment Request</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <h6>Request Details</h6>
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Equipment</th>
                                            <td><?php echo htmlspecialchars($request_data['equipment_name']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Requested By</th>
                                            <td><?php echo htmlspecialchars($request_data['username']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Request Date</th>
                                            <td><?php echo date('M d, Y', strtotime($request_data['request_date'])); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Purpose</th>
                                            <td><?php echo isset($request_data['purpose']) ? htmlspecialchars($request_data['purpose']) : 'N/A'; ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            
                            <form action="requests.php" method="post">
                                <input type="hidden" name="request_id" value="<?php echo $request_data['id']; ?>">
                                
                                <div class="mb-3">
                                    <label for="expected_return_date" class="form-label">Expected Return Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control" id="expected_return_date" name="expected_return_date" required
                                           min="<?php echo date('Y-m-d'); ?>">
                                </div>
                                
                                <div class="d-flex justify-content-end">
                                    <a href="requests.php" class="btn btn-secondary me-2">Cancel</a>
                                    <button type="submit" name="approve_request" class="btn btn-success">
                                        <i class="fas fa-check me-1"></i> Approve Request
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php elseif ($action === 'reject'): ?>
                    <!-- Reject Request Form -->
                    <div class="card mb-4">
                        <div class="card-header bg-danger text-white">
                            <h5 class="card-title mb-0">Reject Equipment Request</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <h6>Request Details</h6>
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Equipment</th>
                                            <td><?php echo htmlspecialchars($request_data['equipment_name']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Requested By</th>
                                            <td><?php echo htmlspecialchars($request_data['username']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Request Date</th>
                                            <td><?php echo date('M d, Y', strtotime($request_data['request_date'])); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Purpose</th>
                                            <td><?php echo htmlspecialchars($request_data['purpose']); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            
                            <form action="requests.php" method="post">
                                <input type="hidden" name="request_id" value="<?php echo $request_data['id']; ?>">
                                
                                <div class="mb-3">
                                    <label for="rejection_reason" class="form-label">Rejection Reason</label>
                                    <textarea class="form-control" id="rejection_reason" name="rejection_reason" rows="3"></textarea>
                                    <div class="form-text">Provide a reason why this request is being rejected (optional).</div>
                                </div>
                                
                                <div class="d-flex justify-content-end">
                                    <a href="requests.php" class="btn btn-secondary me-2">Cancel</a>
                                    <button type="submit" name="reject_request" class="btn btn-danger">
                                        <i class="fas fa-times me-1"></i> Reject Request
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php elseif ($action === 'return'): ?>
                    <!-- Mark as Returned Form -->
                    <div class="card mb-4">
                        <div class="card-header bg-info text-white">
                            <h5 class="card-title mb-0">Mark Equipment as Returned</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <h6>Request Details</h6>
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Equipment</th>
                                            <td><?php echo htmlspecialchars($request_data['equipment_name']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Borrowed By</th>
                                            <td><?php echo htmlspecialchars($request_data['username']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Borrow Date</th>
                                            <td><?php echo date('M d, Y', strtotime($request_data['approval_date'])); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Expected Return</th>
                                            <td><?php echo date('M d, Y', strtotime($request_data['expected_return_date'])); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Status</th>
                                            <td>
                                                <?php if ($request_data['status'] === 'overdue'): ?>
                                                    <span class="badge bg-danger">Overdue</span>
                                                <?php else: ?>
                                                    <span class="badge bg-success">Approved</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            
                            <form action="requests.php" method="post">
                                <input type="hidden" name="request_id" value="<?php echo $request_data['id']; ?>">
                                
                                <div class="mb-3">
                                    <label for="return_condition" class="form-label">Return Condition</label>
                                    <select class="form-select" id="return_condition" name="return_condition">
                                        <option value="Excellent">Excellent - Like new</option>
                                        <option value="Good" selected>Good - Minor wear</option>
                                        <option value="Fair">Fair - Noticeable wear</option>
                                        <option value="Poor">Poor - Significant damage</option>
                                        <option value="Damaged">Damaged - Needs repair</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="return_notes" class="form-label">Notes</label>
                                    <textarea class="form-control" id="return_notes" name="return_notes" rows="3"></textarea>
                                    <div class="form-text">Add any notes about the condition of the returned equipment.</div>
                                </div>
                                
                                <div class="d-flex justify-content-end">
                                    <a href="requests.php" class="btn btn-secondary me-2">Cancel</a>
                                    <button type="submit" name="mark_returned" class="btn btn-info">
                                        <i class="fas fa-undo me-1"></i> Mark as Returned
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Requests List -->
                    <div class="card mb-4">
                        <div class="card-header bg-light">
                            <div class="row align-items-center">
                                <div class="col">
                                    <ul class="nav nav-tabs card-header-tabs">
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo empty($status_filter) ? 'active' : ''; ?>" href="requests.php">
                                                All Requests
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo $status_filter === 'pending' ? 'active' : ''; ?>" href="requests.php?status=pending">
                                                Pending
                                                <?php if (count_pending_requests() > 0): ?>
                                                    <span class="badge bg-danger ms-1"><?php echo count_pending_requests(); ?></span>
                                                <?php endif; ?>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo $status_filter === 'approved' ? 'active' : ''; ?>" href="requests.php?status=approved">
                                                Approved
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo $status_filter === 'overdue' ? 'active' : ''; ?>" href="requests.php?status=overdue">
                                                Overdue
                                                <?php if (count_overdue_requests() > 0): ?>
                                                    <span class="badge bg-danger ms-1"><?php echo count_overdue_requests(); ?></span>
                                                <?php endif; ?>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo $status_filter === 'returned' ? 'active' : ''; ?>" href="requests.php?status=returned">
                                                Returned
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo $status_filter === 'rejected' ? 'active' : ''; ?>" href="requests.php?status=rejected">
                                                Rejected
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-auto">
                                    <div class="input-group">
                                        <input type="text" id="requestSearch" class="form-control" placeholder="Search requests...">
                                        <button class="btn btn-outline-secondary" type="button">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <?php if (count($all_requests) > 0): ?>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Equipment</th>
                                                <th>User</th>
                                                <th>Request Date</th>
                                                <th>Status</th>
                                                <th>Return Date</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($all_requests as $request): ?>
                                                <tr class="request-row">
                                                    <td><?php echo $request['id']; ?></td>
                                                    <td><?php echo htmlspecialchars($request['equipment_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($request['username']); ?></td>
                                                    <td><?php echo htmlspecialchars($request['equipment_name']); ?></td>
                                                    <td><?php echo $request['quantity']; ?></td>
                                                    <td><?php echo date('M d, Y', strtotime($request['request_date'])); ?></td>
                                                    <td><?php echo isset($request['purpose']) ? htmlspecialchars($request['purpose']) : ''; ?></td>
                                                    <td>
                                                        <?php if ($request['status'] === 'pending'): ?>
                                                            <span class="badge bg-warning text-dark">Pending</span>
                                                        <?php elseif ($request['status'] === 'approved'): ?>
                                                            <span class="badge bg-success">Approved</span>
                                                        <?php elseif ($request['status'] === 'rejected'): ?>
                                                            <span class="badge bg-danger">Rejected</span>
                                                        <?php elseif ($request['status'] === 'returned'): ?>
                                                            <span class="badge bg-info">Returned</span>
                                                        <?php elseif ($request['status'] === 'overdue'): ?>
                                                            <span class="badge bg-danger">Overdue</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if (!empty($request['expected_return_date'])): ?>
                                                            <?php if ($request['status'] === 'returned'): ?>
                                                                <span class="text-success">
                                                                    <?php echo date('M d, Y', strtotime($request['actual_return_date'])); ?>
                                                                </span>
                                                            <?php else: ?>
                                                                <?php 
                                                                $expected_date = strtotime($request['expected_return_date']);
                                                                $today = strtotime(date('Y-m-d'));
                                                                $date_class = $expected_date < $today && $request['status'] !== 'returned' ? 'text-danger' : '';
                                                                ?>
                                                                <span class="<?php echo $date_class; ?>">
                                                                    <?php echo date('M d, Y', $expected_date); ?>
                                                                </span>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            -
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if ($request['status'] === 'pending'): ?>
                                                            <a href="requests.php?action=approve&id=<?php echo $request['id']; ?>" class="btn btn-sm btn-success me-1">
                                                                <i class="fas fa-check"></i> Approve
                                                            </a>
                                                            <a href="requests.php?action=reject&id=<?php echo $request['id']; ?>" class="btn btn-sm btn-danger">
                                                                <i class="fas fa-times"></i> Reject
                                                            </a>
                                                        <?php elseif ($request['status'] === 'approved' || $request['status'] === 'overdue'): ?>
                                                            <a href="requests.php?action=return&id=<?php echo $request['id']; ?>" class="btn btn-sm btn-info">
                                                                <i class="fas fa-undo"></i> Return
                                                            </a>
                                                        <?php else: ?>
                                                            <button class="btn btn-sm btn-secondary" disabled>No Actions</button>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-1"></i> No requests found.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php include_once 'includes/footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
    <script>
        // Request search functionality
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('requestSearch');
            if (searchInput) {
                searchInput.addEventListener('keyup', function() {
                    const searchTerm = this.value.toLowerCase();
                    const requestRows = document.querySelectorAll('.request-row');
                    
                    requestRows.forEach(function(row) {
                        const text = row.textContent.toLowerCase();
                        if (text.includes(searchTerm)) {
                            row.style.display = '';
                        } else {
                            row.style.display = 'none';
                        }
                    });
                });
            }
        });
    </script>
</body>
</html>

<head>
    <!-- Existing head content -->
    <style>
        body {
            position: relative;
            background-color: transparent !important;
        }
        
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('../images/sgbit.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            opacity: 0.2;
            z-index: -1;
        }
    </style>
</head>