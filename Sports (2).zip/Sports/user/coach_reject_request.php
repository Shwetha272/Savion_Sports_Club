<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('../login.php');
}

// Check if user is coach
if (!has_role('coach')) {
    set_message('error', 'You do not have permission to access this page.');
    redirect('dashboard.php');
}

// Check if request ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    set_message('error', 'Invalid request ID.');
    redirect('coach_requests.php');
}

$request_id = sanitize_input($_GET['id']);

// Get request details
$request = get_request_by_id($request_id);

// Check if request exists and is pending
if (!$request || $request['status'] != 'pending') {
    set_message('error', 'Invalid request or request is not pending.');
    redirect('coach_requests.php');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $reason = sanitize_input($_POST['reason']);
    
    // Update request status to rejected
    $sql = "UPDATE equipment_requests SET 
            status = 'rejected', 
            rejection_reason = ?,
            rejected_by = ?,
            rejection_date = NOW()
            WHERE id = ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sii", $reason, $_SESSION['id'], $request_id);
    
    if (mysqli_stmt_execute($stmt)) {
        // Create notification for the user
        $message = "Your request for " . $request['equipment_name'] . " has been rejected.";
        $link = "request_details.php?id=" . $request_id;
        create_notification($request['user_id'], 'request_update', $message, $link);
        
        set_message('success', 'Request has been rejected successfully.');
        redirect('coach_requests.php');
    } else {
        set_message('error', 'Failed to reject request. Please try again.');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reject Request - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include_once 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Reject Equipment Request</h5>
                    </div>
                    <div class="card-body">
                        <?php echo display_messages(); ?>
                        
                        <div class="alert alert-info">
                            <p><strong>Student:</strong> <?php echo htmlspecialchars($request['full_name'] ?: $request['username']); ?></p>
                            <p><strong>Equipment:</strong> <?php echo htmlspecialchars($request['equipment_name']); ?></p>
                            <p><strong>Quantity:</strong> <?php echo $request['quantity']; ?></p>
                            <p><strong>Request Date:</strong> <?php echo date('M d, Y', strtotime($request['request_date'])); ?></p>
                            <p><strong>Purpose:</strong> <?php echo htmlspecialchars($request['purpose']); ?></p>
                        </div>
                        
                        <form method="post" action="">
                            <div class="mb-3">
                                <label for="reason" class="form-label">Reason for Rejection</label>
                                <textarea class="form-control" id="reason" name="reason" rows="3" required></textarea>
                                <div class="form-text">Provide a reason why this request is being rejected.</div>
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <a href="coach_requests.php" class="btn btn-secondary">Cancel</a>
                                <button type="submit" class="btn btn-danger">Reject Request</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>