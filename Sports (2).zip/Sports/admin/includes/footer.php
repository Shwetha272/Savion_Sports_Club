<footer class="footer mt-auto py-3 bg-light">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <span class="text-muted">&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> - All rights reserved</span>
            </div>
            <div class="col-md-6 text-end">
                <span class="text-muted">Admin Panel v1.0</span>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap JS Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom Admin Scripts -->
<script>
    // Enable Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Auto-hide alerts after 5 seconds
    window.setTimeout(function() {
        $(".alert-dismissible").fadeTo(500, 0).slideUp(500, function(){
            $(this).remove(); 
        });
    }, 5000);
</script>

</div>
            <!-- End of Page Content -->
            
            <!-- Footer -->
            <footer class="sticky-footer bg-white mt-4">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; <?php echo SITE_NAME; ?> <?php echo date('Y'); ?></span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Admin Wrapper -->
    
    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="../logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap core JavaScript-->
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom scripts for admin area -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle the side navigation
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebarToggleTop = document.getElementById('sidebarToggleTop');
        
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function(e) {
                e.preventDefault();
                document.querySelector('.admin-wrapper').classList.toggle('toggled');
                document.querySelector('.admin-sidebar').classList.toggle('toggled');
                document.querySelector('.admin-content').classList.toggle('toggled');
                
                // Change icon direction
                const icon = this.querySelector('i');
                if (icon.classList.contains('fa-angle-left')) {
                    icon.classList.remove('fa-angle-left');
                    icon.classList.add('fa-angle-right');
                } else {
                    icon.classList.remove('fa-angle-right');
                    icon.classList.add('fa-angle-left');
                }
            });
        }
        
        if (sidebarToggleTop) {
            sidebarToggleTop.addEventListener('click', function(e) {
                e.preventDefault();
                document.querySelector('.admin-wrapper').classList.toggle('toggled');
                document.querySelector('.admin-sidebar').classList.toggle('toggled');
                document.querySelector('.admin-content').classList.toggle('toggled');
            });
        }
        
        // Close any open menu dropdowns when window is resized
        window.addEventListener('resize', function() {
            const vw = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0);
            
            if (vw < 768) {
                document.querySelector('.admin-sidebar').classList.remove('toggled');
                document.querySelector('.admin-content').classList.remove('toggled');
            }
        });
        
        // Add active class to nav items based on URL
        const currentPage = window.location.pathname.split("/").pop();
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href === currentPage) {
                link.classList.add('active');
            }
        });
        
        // Initialize tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
    </script>
    
    <?php if (isset($extra_js)): ?>
        <?php echo $extra_js; ?>
    <?php endif; ?>
</body>
</html>