<?php
$page_title = "Equipment Management";
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and is an admin
if (!is_logged_in() || !has_role('admin')) {
    redirect('../login.php');
}

// Get admin information
$admin = get_user($_SESSION['id']);

// Handle equipment actions (add, edit, delete)
$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$equipment_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$success_message = '';
$error_message = '';

// Process form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_equipment']) || isset($_POST['update_equipment'])) {
        // Get form data
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);
        $quantity = intval($_POST['quantity']);
        $category = trim($_POST['category']);
        $condition = isset($_POST['condition']) ? $_POST['condition'] : 'new'; // Default to 'new' if not set
        $location = trim($_POST['location']);
        $available = isset($_POST['available']) ? 1 : 0;
        
        // Validate form data
        if (empty($name)) {
            $error_message = "Equipment name is required.";
        } elseif ($quantity < 0) {
            $error_message = "Quantity cannot be negative.";
        } else {
            // Process image upload if provided
            $image_path = '';
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                // Make sure the upload directory exists and has proper permissions
                $upload_dir = '../uploads/equipment/';
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                
                $file_name = time() . '_' . basename($_FILES['image']['name']);
                $target_file = $upload_dir . $file_name;
                
                $image_file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
                $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
                
                if (!in_array($image_file_type, $allowed_types)) {
                    $error_message = "Only JPG, JPEG, PNG & GIF files are allowed.";
                } elseif ($_FILES['image']['size'] > 5000000) { // 5MB max
                    $error_message = "File is too large. Maximum size is 5MB.";
                } elseif (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                    // Fix the image path to be relative to the site root
                    $image_path = 'uploads/equipment/' . $file_name;
                } else {
                    $error_message = "Failed to upload image. Error code: " . $_FILES['image']['error'];
                    // Check directory permissions
                    if (!is_writable($upload_dir)) {
                        $error_message .= " Upload directory is not writable.";
                    }
                }
            }
            
            if (empty($error_message)) {
                if (isset($_POST['add_equipment'])) {
                    // Add new equipment
                    $result = add_equipment($name, $description, $quantity, $category, $condition, $location, $available, $image_path);
                    if ($result) {
                        $success_message = "Equipment added successfully.";
                        // Redirect to avoid form resubmission
                        redirect("equipment.php?success=" . urlencode($success_message));
                    } else {
                        $error_message = "Failed to add equipment.";
                    }
                } else {
                    // Update existing equipment
                    $equipment_id = intval($_POST['equipment_id']);
                    $current_equipment = get_equipment($equipment_id);
                    
                    // If no new image was uploaded, keep the existing one
                    if (empty($image_path) && isset($current_equipment['image'])) {
                        $image_path = $current_equipment['image'];
                    }
                    
                    $result = update_equipment($equipment_id, $name, $description, $quantity, $category, $condition, $location, $available, $image_path);
                    if ($result) {
                        $success_message = "Equipment updated successfully.";
                        // Redirect to avoid form resubmission
                        redirect("equipment.php?success=" . urlencode($success_message));
                    } else {
                        $error_message = "Failed to update equipment.";
                    }
                }
            }
        }
    } elseif (isset($_POST['delete_equipment'])) {
        // Delete equipment
        $equipment_id = intval($_POST['equipment_id']);
        $result = delete_equipment($equipment_id);
        if ($result) {
            $success_message = "Equipment deleted successfully.";
            // Redirect to avoid form resubmission
            redirect("equipment.php?success=" . urlencode($success_message));
        } else {
            $error_message = "Failed to delete equipment.";
        }
    }
}

// Get equipment data based on action
$equipment_data = [];
if ($action === 'edit' && $equipment_id > 0) {
    $equipment_data = get_equipment($equipment_id);
    if (!$equipment_data) {
        $error_message = "Equipment not found.";
        $action = 'list';
    }
}

// Get all equipment for listing
$all_equipment = [];
if ($action === 'list') {
    $all_equipment = get_all_equipment();
}

// Get equipment categories for dropdown
$equipment_categories = get_equipment_categories();

// Get success message from URL if redirected
if (isset($_GET['success'])) {
    $success_message = $_GET['success'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Add this right after your include_once 'includes/header.php'; line -->
    <!-- Add custom styles for background image -->
    <style>
        body {
            position: relative;
            background-color: transparent !important;
        }
        
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('../images/sgbit.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            opacity: 0.2;
            z-index: -1;
        }
    </style>
</head>
<body>
    <?php include_once 'includes/header.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-2">
                <?php include_once 'includes/sidebar.php'; ?>
            </div>
            <div class="col-md-10">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-dumbbell me-2"></i> Equipment Management</h2>
                    <?php if ($action === 'list'): ?>
                        <a href="equipment.php?action=add" class="btn btn-primary">
                            <i class="fas fa-plus-circle me-1"></i> Add New Equipment
                        </a>
                    <?php else: ?>
                        <a href="equipment.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-1"></i> Back to List
                        </a>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($success_message)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-1"></i> <?php echo $success_message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($error_message)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-circle me-1"></i> <?php echo $error_message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($action === 'add' || $action === 'edit'): ?>
                    <!-- Add/Edit Equipment Form -->
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="card-title mb-0">
                                <?php echo $action === 'add' ? 'Add New Equipment' : 'Edit Equipment'; ?>
                            </h5>
                        </div>
                        <div class="card-body">
                            <form action="equipment.php" method="post" enctype="multipart/form-data">
                                <?php if ($action === 'edit'): ?>
                                    <input type="hidden" name="equipment_id" value="<?php echo $equipment_data['id']; ?>">
                                <?php endif; ?>
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="name" class="form-label">Equipment Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="name" name="name" required
                                               value="<?php echo $action === 'edit' ? htmlspecialchars($equipment_data['name']) : ''; ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="category" class="form-label">Category</label>
                                        <select class="form-select" id="category" name="category">
                                            <option value="">Select Category</option>
                                            <?php foreach ($equipment_categories as $category): ?>
                                                <option value="<?php echo htmlspecialchars($category); ?>" 
                                                        <?php echo ($action === 'edit' && $equipment_data['category'] === $category) ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($category); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control" id="description" name="description" rows="3"><?php echo $action === 'edit' ? htmlspecialchars($equipment_data['description']) : ''; ?></textarea>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="quantity" class="form-label">Quantity <span class="text-danger">*</span></label>
                                        <input type="number" class="form-control" id="quantity" name="quantity" min="0" required
                                               value="<?php echo $action === 'edit' ? intval($equipment_data['quantity']) : '1'; ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="condition" class="form-label">Condition</label>
                                        <select class="form-select" id="condition" name="condition">
                                            <option value="New" <?php echo ($action === 'edit' && $equipment_data['condition'] === 'New') ? 'selected' : ''; ?>>New</option>
                                            <option value="Excellent" <?php echo ($action === 'edit' && $equipment_data['condition'] === 'Excellent') ? 'selected' : ''; ?>>Excellent</option>
                                            <option value="Good" <?php echo ($action === 'edit' && $equipment_data['condition'] === 'Good') ? 'selected' : ''; ?>>Good</option>
                                            <option value="Fair" <?php echo ($action === 'edit' && $equipment_data['condition'] === 'Fair') ? 'selected' : ''; ?>>Fair</option>
                                            <option value="Poor" <?php echo ($action === 'edit' && $equipment_data['condition'] === 'Poor') ? 'selected' : ''; ?>>Poor</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="location" class="form-label">Storage Location</label>
                                        <input type="text" class="form-control" id="location" name="location"
                                               value="<?php echo $action === 'edit' ? htmlspecialchars($equipment_data['location']) : ''; ?>">
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="image" class="form-label">Equipment Image</label>
                                    <?php if ($action === 'edit' && !empty($equipment_data['image'])): ?>
                                        <div class="mb-2">
                                            <img src="../<?php echo htmlspecialchars($equipment_data['image']); ?>" alt="Current Image" class="img-thumbnail" style="max-height: 150px;">
                                            <p class="small text-muted">Current image. Upload a new one to replace it.</p>
                                        </div>
                                    <?php endif; ?>
                                    <input type="file" class="form-control" id="image" name="image">
                                    <div class="form-text">Recommended size: 800x600px. Max file size: 5MB.</div>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="available" name="available" value="1"
                                           <?php echo ($action === 'edit' && $equipment_data['available'] == 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="available">Available for Borrowing</label>
                                </div>
                                
                                <div class="d-flex justify-content-end">
                                    <a href="equipment.php" class="btn btn-secondary me-2">Cancel</a>
                                    <button type="submit" name="<?php echo $action === 'add' ? 'add_equipment' : 'update_equipment'; ?>" class="btn btn-primary">
                                        <?php echo $action === 'add' ? 'Add Equipment' : 'Update Equipment'; ?>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php elseif ($action === 'delete'): ?>
                    <!-- Delete Confirmation -->
                    <?php $equipment_data = get_equipment($equipment_id); ?>
                    <?php if ($equipment_data): ?>
                        <div class="card mb-4">
                            <div class="card-header bg-danger text-white">
                                <h5 class="card-title mb-0">Confirm Deletion</h5>
                            </div>
                            <div class="card-body">
                                <p>Are you sure you want to delete the following equipment?</p>
                                <p><strong><?php echo htmlspecialchars($equipment_data['name']); ?></strong></p>
                                <p class="text-danger">This action cannot be undone.</p>
                                
                                <form action="equipment.php" method="post">
                                    <input type="hidden" name="equipment_id" value="<?php echo $equipment_data['id']; ?>">
                                    <div class="d-flex justify-content-end">
                                        <a href="equipment.php" class="btn btn-secondary me-2">Cancel</a>
                                        <button type="submit" name="delete_equipment" class="btn btn-danger">Delete Equipment</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle me-1"></i> Equipment not found.
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <!-- Equipment List -->
                    <div class="card mb-4">
                        <div class="card-header bg-light">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h5 class="card-title mb-0">Equipment Inventory</h5>
                                </div>
                                <div class="col-auto">
                                    <div class="input-group">
                                        <input type="text" id="equipmentSearch" class="form-control" placeholder="Search equipment...">
                                        <button class="btn btn-outline-secondary" type="button">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <?php if (count($all_equipment) > 0): ?>
                                <div class="row" id="equipmentGrid">
                                    <?php foreach ($all_equipment as $equipment): ?>
                                        <div class="col-md-4 col-lg-3 mb-4 equipment-item">
                                            <div class="card equipment-card">
                                                <?php if (!empty($equipment['image'])): ?>
                                                    <!-- Debug: <?php echo $equipment['image']; ?> -->
                                                    <img src="../<?php echo htmlspecialchars($equipment['image']); ?>" class="equipment-image" alt="<?php echo htmlspecialchars($equipment['name']); ?>" onerror="this.onerror=null; this.src='../assets/img/no-image.jpg'; console.log('Image failed to load: ../' + '<?php echo htmlspecialchars($equipment['image']); ?>');">
                                                <?php else: ?>
                                                    <div class="equipment-image bg-light d-flex align-items-center justify-content-center">
                                                        <i class="fas fa-dumbbell fa-3x text-muted"></i>
                                                    </div>
                                                <?php endif; ?>
                                                
                                                <div class="equipment-status">
                                                    <span class="badge bg-<?php echo $equipment['available'] ? 'success' : 'danger'; ?>">
                                                        <?php echo $equipment['available'] ? 'Available' : 'Unavailable'; ?>
                                                    </span>
                                                </div>
                                                
                                                <div class="equipment-quantity">
                                                    <i class="fas fa-cubes me-1"></i> <?php echo $equipment['quantity']; ?>
                                                </div>
                                                
                                                <div class="card-body">
                                                    <h5 class="card-title"><?php echo htmlspecialchars($equipment['name']); ?></h5>
                                                    <p class="card-text small text-muted">
                                                        <?php if (!empty($equipment['category'])): ?>
                                                            <span class="badge bg-info"><?php echo htmlspecialchars($equipment['category']); ?></span>
                                                        <?php endif; ?>
                                                        <?php if (!empty($equipment['condition'])): ?>
                                                            <span class="badge bg-secondary"><?php echo htmlspecialchars($equipment['condition']); ?></span>
                                                        <?php endif; ?>
                                                    </p>
                                                    <p class="card-text small">
                                                        <?php echo !empty($equipment['description']) ? substr(htmlspecialchars($equipment['description']), 0, 100) . '...' : 'No description available.'; ?>
                                                    </p>
                                                </div>
                                                <div class="card-footer bg-transparent d-flex justify-content-between">
                                                    <a href="equipment.php?action=edit&id=<?php echo $equipment['id']; ?>" class="btn btn-sm btn-primary">
                                                        <i class="fas fa-edit"></i> Edit
                                                    </a>
                                                    <a href="equipment.php?action=delete&id=<?php echo $equipment['id']; ?>" class="btn btn-sm btn-danger">
                                                        <i class="fas fa-trash"></i> Delete
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-1"></i> No equipment found. Add some equipment to get started.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php include_once 'includes/footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
    <script>
        // Equipment search functionality
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('equipmentSearch');
            if (searchInput) {
                searchInput.addEventListener('keyup', function() {
                    const searchTerm = this.value.toLowerCase();
                    const equipmentItems = document.querySelectorAll('.equipment-item');
                    
                    equipmentItems.forEach(function(item) {
                        const equipmentName = item.querySelector('.card-title').textContent.toLowerCase();
                        const equipmentDesc = item.querySelector('.card-text:last-child').textContent.toLowerCase();
                        const equipmentCategory = item.querySelector('.badge.bg-info') ? 
                                                 item.querySelector('.badge.bg-info').textContent.toLowerCase() : '';
                        
                        if (equipmentName.includes(searchTerm) || 
                            equipmentDesc.includes(searchTerm) || 
                            equipmentCategory.includes(searchTerm)) {
                            item.style.display = '';
                        } else {
                            item.style.display = 'none';
                        }
                    });
                });
            }
        });
    </script>
</body>
</html>