<?php
$page_title = "Borrowing History";
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('../login.php');
}

// Check if user is student or coach
if (has_role('admin')) {
    redirect('../admin/dashboard.php');
}

// Get user's borrowing history
$history = get_user_borrowing_history($_SESSION['id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php if (has_role('coach')): ?>
                    <?php include_once 'coach_sidebar.php'; ?>
                <?php else: ?>
                    <?php include_once 'sidebar.php'; ?>
                <?php endif; ?>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">My Borrowing History</h5>
                    </div>
                    <div class="card-body">
                        <?php if (count($history) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Equipment</th>
                                            <th>Quantity</th>
                                            <th>Requested On</th>
                                            <th>Borrowed On</th>
                                            <th>Return By</th>
                                            <th>Returned On</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($history as $item): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['equipment_name']); ?></td>
                                                <td><?php echo $item['quantity']; ?></td>
                                                <td><?php echo date('M d, Y', strtotime($item['request_date'])); ?></td>
                                                <td>
                                                    <?php 
                                                    echo !empty($item['approved_date']) 
                                                        ? date('M d, Y', strtotime($item['approved_date'])) 
                                                        : '–';
                                                    ?>
                                                </td>
                                                <td><?php echo date('M d, Y', strtotime($item['expected_return_date'])); ?></td>
                                                <td>
                                                    <?php 
                                                    echo !empty($item['actual_return_date']) 
                                                        ? date('M d, Y', strtotime($item['actual_return_date'])) 
                                                        : '–';
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php 
                                                    $status_class = '';
                                                    switch ($item['status']) {
                                                        case 'approved':
                                                            $status_class = 'success';
                                                            $status_text = 'Active';
                                                            break;
                                                        case 'returned':
                                                            $status_class = 'info';
                                                            $status_text = 'Returned';
                                                            break;
                                                        case 'overdue':
                                                            $status_class = 'danger';
                                                            $status_text = 'Overdue';
                                                            break;
                                                        default:
                                                            $status_class = 'secondary';
                                                            $status_text = ucfirst($item['status']);
                                                    }
                                                    ?>
                                                    <span class="badge bg-<?php echo $status_class; ?>">
                                                        <?php echo $status_text; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="request_details.php?id=<?php echo $item['id']; ?>" class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <?php if ($item['status'] == 'approved' || $item['status'] == 'overdue'): ?>
                                                    <a href="return_equipment.php?id=<?php echo $item['id']; ?>" class="btn btn-sm btn-success">
                                                        <i class="fas fa-undo"></i>
                                                    </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> You don't have any borrowing history yet.
                                <a href="equipment.php" class="alert-link">Browse equipment</a> to make a request.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>