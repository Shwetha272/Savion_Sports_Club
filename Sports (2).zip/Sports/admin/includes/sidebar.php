<div class="list-group mb-4">
    <a href="dashboard.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
        <i class="fas fa-tachometer-alt me-2"></i> Dashboard
    </a>
    <a href="equipment.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'equipment.php' ? 'active' : ''; ?>">
        <i class="fas fa-dumbbell me-2"></i> Manage Equipment
    </a>
    <a href="requests.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'requests.php' ? 'active' : ''; ?>">
        <i class="fas fa-clipboard-list me-2"></i> Manage Requests
        <?php $pending = count_pending_requests(); ?>
        <?php if ($pending > 0): ?>
            <span class="badge bg-warning float-end"><?php echo $pending; ?></span>
        <?php endif; ?>
    </a>
    <a href="users.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
        <i class="fas fa-users me-2"></i> Manage Users
    </a>
    <a href="reports.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>">
        <i class="fas fa-chart-bar me-2"></i> Reports
    </a>
    <a href="notifications.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'notifications.php' ? 'active' : ''; ?>">
        <i class="fas fa-bell me-2"></i> Notifications
        <?php $unread = count_admin_notifications(); ?>
        <?php if ($unread > 0): ?>
            <span class="badge bg-danger float-end"><?php echo $unread; ?></span>
        <?php endif; ?>
    </a>
    <a href="settings.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
        <i class="fas fa-cog me-2"></i> Settings
    </a>
    <a href="profile.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>">
        <i class="fas fa-user-cog me-2"></i> My Profile
    </a>
    <a href="../logout.php" class="list-group-item list-group-item-action text-danger">
        <i class="fas fa-sign-out-alt me-2"></i> Logout
    </a>
</div>