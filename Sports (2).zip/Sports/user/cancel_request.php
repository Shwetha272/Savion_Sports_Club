<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('../login.php');
}

// Check if user is student or coach
if (has_role('admin')) {
    redirect('../admin/dashboard.php');
}

// Check if request ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    set_message('error', 'Invalid request ID.');
    redirect('my_requests.php');
}

$request_id = sanitize_input($_GET['id']);
$user_id = $_SESSION['id'];

// Check if the request exists and belongs to the user
$sql = "SELECT er.*, e.name as equipment_name 
        FROM equipment_requests er
        JOIN equipment e ON er.equipment_id = e.id
        WHERE er.id = ? AND er.user_id = ? AND er.status = 'pending'";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $request_id, $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {
    set_message('error', 'Request not found, already processed, or you do not have permission to cancel it.');
    redirect('my_requests.php');
}

$request = mysqli_fetch_assoc($result);

// Cancel the request
$sql = "UPDATE equipment_requests SET status = 'cancelled' WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $request_id);

if (mysqli_stmt_execute($stmt)) {
    // Create notification for admin
    $admin_message = "Equipment request #{$request_id} for {$request['equipment_name']} has been cancelled by " . $_SESSION['username'] . ".";
    create_admin_notification($admin_message, 'request_update');
    
    // Create notification for user
    $user_message = "Your request for {$request['equipment_name']} has been cancelled.";
    create_user_notification($user_id, $user_message, 'request_update');
    
    set_message('success', 'Equipment request cancelled successfully.');
} else {
    set_message('error', 'Failed to cancel the request. Please try again later.');
}

redirect('my_requests.php');
?>