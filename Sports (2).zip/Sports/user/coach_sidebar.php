<div class="list-group mb-4">
    <a href="coach_dashboard.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'coach_dashboard.php' ? 'active' : ''; ?>">
        <i class="fas fa-tachometer-alt me-2"></i> Dashboard
    </a>
    <a href="equipment.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'equipment.php' ? 'active' : ''; ?>">
        <i class="fas fa-dumbbell me-2"></i> Equipment
    </a>
    <a href="requests.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'requests.php' ? 'active' : ''; ?>">
        <i class="fas fa-clipboard-list me-2"></i> My Requests
    </a>
    <a href="history.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'history.php' ? 'active' : ''; ?>">
        <i class="fas fa-history me-2"></i> Borrowing History
    </a>
    <a href="notifications.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'notifications.php' ? 'active' : ''; ?>">
        <i class="fas fa-bell me-2"></i> Notifications
        <?php $unread = count_unread_notifications($_SESSION['id']); ?>
        <?php if ($unread > 0): ?>
            <span class="badge bg-danger float-end"><?php echo $unread; ?></span>
        <?php endif; ?>
    </a>
    <a href="profile.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>">
        <i class="fas fa-user me-2"></i> My Profile
    </a>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Quick Actions</h5>
    </div>
    <div class="card-body">
        <a href="equipment.php?action=request" class="btn btn-primary btn-sm d-block mb-2">
            <i class="fas fa-plus-circle me-2"></i> New Request
        </a>
        <a href="requests.php?status=approved" class="btn btn-success btn-sm d-block mb-2">
            <i class="fas fa-check-circle me-2"></i> Approved Items
        </a>
        <a href="../logout.php" class="btn btn-danger btn-sm d-block">
            <i class="fas fa-sign-out-alt me-2"></i> Logout
        </a>
    </div>
</div>