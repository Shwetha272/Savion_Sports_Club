<?php
$page_title = "Return Equipment";
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('login.php');
}

// Get user information
$user = get_user($_SESSION['id']);

// Check if request ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    set_message('error', 'Invalid request ID.');
    redirect('dashboard.php');
}

$request_id = intval($_GET['id']);
$request = get_request($request_id);

// Verify that the request exists and belongs to the current user
if (!$request || $request['user_id'] != $_SESSION['id']) {
    set_message('error', 'Request not found or you do not have permission to access it.');
    redirect('dashboard.php');
}

// Verify that the request is in 'approved' status
if ($request['status'] !== 'approved' && $request['status'] !== 'overdue') {
    set_message('error', 'This equipment cannot be returned because it is not currently borrowed.');
    redirect('dashboard.php');
}

// Get equipment details
$equipment = get_equipment($request['equipment_id']);

// Process form submission
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['return_equipment'])) {
    // Validate form data
    $return_condition = isset($_POST['return_condition']) ? trim($_POST['return_condition']) : '';
    $return_notes = isset($_POST['return_notes']) ? trim($_POST['return_notes']) : '';
    
    if (empty($return_condition)) {
        $error_message = 'Please select the condition of the equipment.';
    } else {
        // Request return
        $result = request_return($request_id, $return_condition, $return_notes);
        
        if ($result) {
            set_message('success', 'Return request submitted successfully. Please return the equipment to the sports office.');
            redirect('dashboard.php');
        } else {
            $error_message = 'Failed to submit return request. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/user_header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include_once '../includes/user_sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0">Return Equipment</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($success_message)): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="fas fa-check-circle me-1"></i> <?php echo $success_message; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($error_message)): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="fas fa-exclamation-circle me-1"></i> <?php echo $error_message; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h6>Equipment Details</h6>
                                <table class="table table-bordered">
                                    <tr>
                                        <th>Equipment</th>
                                        <td><?php echo htmlspecialchars($equipment['name']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Borrow Date</th>
                                        <td><?php echo isset($request['approval_date']) ? date('M d, Y', strtotime($request['approval_date'])) : 'N/A'; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Expected Return</th>
                                        <td>
                                            <?php 
                                            $expected_date = strtotime($request['expected_return_date']);
                                            $today = strtotime(date('Y-m-d'));
                                            $date_class = $expected_date < $today ? 'text-danger' : '';
                                            ?>
                                            <span class="<?php echo $date_class; ?>">
                                                <?php echo date('M d, Y', $expected_date); ?>
                                                <?php if ($expected_date < $today): ?>
                                                    <span class="badge bg-danger ms-1">Overdue</span>
                                                <?php endif; ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Status</th>
                                        <td>
                                            <?php if ($request['status'] === 'overdue'): ?>
                                                <span class="badge bg-danger">Overdue</span>
                                            <?php else: ?>
                                                <span class="badge bg-success">Approved</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        
                        <form action="return_equipment.php?id=<?php echo $request_id; ?>" method="post">
                            <div class="mb-3">
                                <label for="return_condition" class="form-label">Equipment Condition <span class="text-danger">*</span></label>
                                <select class="form-select" id="return_condition" name="return_condition" required>
                                    <option value="">-- Select Condition --</option>
                                    <option value="Excellent">Excellent - Like new</option>
                                    <option value="Good">Good - Minor wear</option>
                                    <option value="Fair">Fair - Noticeable wear</option>
                                    <option value="Poor">Poor - Significant damage</option>
                                    <option value="Damaged">Damaged - Needs repair</option>
                                </select>
                                <div class="form-text">Please select the current condition of the equipment.</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="return_notes" class="form-label">Notes</label>
                                <textarea class="form-control" id="return_notes" name="return_notes" rows="3"></textarea>
                                <div class="form-text">Add any notes about the condition of the equipment (optional).</div>
                            </div>
                            
                            <div class="d-flex justify-content-end">
                                <a href="dashboard.php" class="btn btn-secondary me-2">Cancel</a>
                                <button type="submit" name="return_equipment" class="btn btn-primary">
                                    <i class="fas fa-undo me-1"></i> Submit Return Request
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/user_footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>