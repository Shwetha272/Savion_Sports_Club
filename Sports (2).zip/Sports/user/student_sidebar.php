<div class="list-group">
    <a href="dashboard.php" class="list-group-item list-group-item-action">Dashboard</a>
    <a href="equipment.php" class="list-group-item list-group-item-action">Browse Equipment</a>
    <a href="requests.php" class="list-group-item list-group-item-action">My Requests</a>
    <a href="history.php" class="list-group-item list-group-item-action">Borrowing History</a>
    <a href="notifications.php" class="list-group-item list-group-item-action">Notifications</a>
    <a href="../logout.php" class="list-group-item list-group-item-action text-danger">Logout</a>
</div>