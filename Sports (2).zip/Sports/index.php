<?php
$page_title = "Home";
require_once 'includes/config.php';
require_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@400;500;600;700;800&display=swap');
        
        :root {
            --primary-color: #3498db;
            --secondary-color: #2ecc71;
            --accent-color: #e74c3c;
            --gradient-1: linear-gradient(45deg, #3498db, #2ecc71);
            --gradient-2: linear-gradient(135deg, #e74c3c, #f39c12);
            --gradient-3: linear-gradient(90deg, #9b59b6, #3498db);
        }
        
        body {
            background-image: url('images/sgbit.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-repeat: no-repeat;
            background-color: white;
            position: relative;
            font-family: 'Poppins', sans-serif;
        }
        
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('images/sgbit.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            opacity: 0.2;
            z-index: -1;
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
        }
        
        .navbar-brand {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            letter-spacing: 1px;
            background: var(--gradient-1);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent !important;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .content-wrapper {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 40px;
            border-radius: 15px;
            margin-top: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-top: 5px solid var(--primary-color);
            border-bottom: 5px solid var(--secondary-color);
            position: relative;
            overflow: hidden;
        }
        
        .content-wrapper::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(52, 152, 219, 0.1) 0%, rgba(46, 204, 113, 0.1) 100%);
            z-index: -1;
        }
        
        .content-wrapper:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }
        
        .display-4 {
            font-weight: 800;
            color: #2c3e50;
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
        }
        
        .display-4 span {
            display: inline-block;
        }
        
        .display-4 .gradient-text {
            background: var(--gradient-1);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .lead {
            font-size: 1.5rem;
            font-weight: 500;
            background: var(--gradient-3);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .card {
            background-color: rgba(255, 255, 255, 0.9);
            border: none;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            height: 100%;
            position: relative;
        }
        
        .card::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: var(--gradient-1);
            transform: scaleX(0);
            transform-origin: left;
            transition: transform 0.5s ease;
        }
        
        .card:hover::after {
            transform: scaleX(1);
        }
        
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.12);
        }
        
        .card-body {
            padding: 2rem;
            position: relative;
            z-index: 1;
        }
        
        .card-body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(52, 152, 219, 0.05) 0%, rgba(46, 204, 113, 0.05) 100%);
            z-index: -1;
            opacity: 0;
            transition: opacity 0.5s ease;
        }
        
        .card:hover .card-body::before {
            opacity: 1;
        }
        
        .btn {
            border-radius: 30px;
            padding: 10px 25px;
            font-weight: 500;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            z-index: 1;
        }
        
        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, rgba(255,255,255,0.2), rgba(255,255,255,0));
            transition: all 0.5s ease;
            z-index: -1;
        }
        
        .btn:hover::before {
            left: 100%;
        }
        
        .btn-primary {
            background: var(--gradient-1);
            border: none;
        }
        
        .btn-primary:hover {
            background: linear-gradient(45deg, #2980b9, #27ae60);
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4);
        }
        
        .btn-outline-primary {
            color: var(--primary-color);
            border: 2px solid var(--primary-color);
            background: transparent;
        }
        
        .btn-outline-primary:hover {
            background: var(--gradient-1);
            color: white;
            border-color: transparent;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4);
        }
        
        .navbar {
            background: var(--gradient-1) !important;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        footer {
            background: var(--gradient-3) !important;
            position: relative;
            overflow: hidden;
        }
        
        footer::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDBweCIgdmlld0JveD0iMCAwIDEyODAgMTQwIiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIGZpbGw9IiNmZmZmZmYiPjxwYXRoIGQ9Ik0xMjgwIDE0MFYwUzk5My40NiAxNDAgNjQwIDEzOSAwIDAgMCAwdjE0MHoiLz48L2c+PC9zdmc+');
            background-size: 100% 100px;
            top: -50px;
            opacity: 0.1;
        }
        
        .fa-3x {
            background: var(--gradient-2);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent !important;
            transition: transform 0.3s ease;
        }
        
        .card:hover .fa-3x {
            transform: scale(1.2) rotate(5deg);
        }
        
        /* Animation classes */
        .pulse {
            animation: pulse-animation 2s infinite;
        }
        
        @keyframes pulse-animation {
            0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(52, 152, 219, 0.7); }
            50% { transform: scale(1.05); box-shadow: 0 0 0 10px rgba(52, 152, 219, 0); }
            100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(52, 152, 219, 0); }
        }
        
        .floating {
            animation: floating 3s ease-in-out infinite;
        }
        
        @keyframes floating {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-15px); }
            100% { transform: translateY(0px); }
        }
        
        .rotate-icon {
            transition: transform 0.5s ease;
        }
        
        .card:hover .rotate-icon {
            transform: rotateY(180deg);
        }
        
        .shine-effect {
            position: relative;
            overflow: hidden;
        }
        
        .shine-effect::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -60%;
            width: 20%;
            height: 200%;
            background: rgba(255, 255, 255, 0.3);
            transform: rotate(30deg);
            transition: all 0.7s ease;
        }
        
        .shine-effect:hover::after {
            left: 120%;
        }
        
        .navbar-img {
            transition: all 0.5s cubic-bezier(0.68, -0.55, 0.27, 1.55);
            border: 3px solid transparent;
        }
        
        .navbar-img:hover {
            transform: rotate(10deg) scale(1.2);
            border-color: #fff;
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.6);
            z-index: 10;
        }
        
        .nav-link {
            position: relative;
            transition: all 0.3s ease;
            padding: 8px 15px !important;
            margin: 0 5px;
            overflow: hidden;
            color: white !important;
        }
        
        .nav-link::before {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background-color: #fff;
            transform: translateX(-100%);
            transition: transform 0.3s ease;
        }
        
        .nav-link:hover::before {
            transform: translateX(0);
        }
        
        .nav-link.active::before {
            transform: translateX(0);
        }
        
        /* Rainbow text animation */
        .rainbow-text {
            animation: rainbow-text 5s linear infinite;
            background-size: 400% 100%;
            background-image: linear-gradient(90deg, 
                #ff0000, #ff7f00, #ffff00, #00ff00, #0000ff, #4b0082, #8b00ff, #ff0000);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent !important;
        }
        
        @keyframes rainbow-text {
            0% { background-position: 0% 50%; }
            100% { background-position: 400% 50%; }
        }
        
        /* Colorful card borders */
        .card:nth-child(1) {
            border-left: 4px solid #3498db;
        }
        
        .card:nth-child(2) {
            border-left: 4px solid #2ecc71;
        }
        
        .card:nth-child(3) {
            border-left: 4px solid #e74c3c;
        }
        
        /* Glowing effect */
        .glow {
            animation: glow 2s ease-in-out infinite alternate;
        }
        
        @keyframes glow {
            from {
                text-shadow: 0 0 5px #fff, 0 0 10px #fff, 0 0 15px #3498db, 0 0 20px #3498db;
            }
            to {
                text-shadow: 0 0 10px #fff, 0 0 20px #fff, 0 0 30px #2ecc71, 0 0 40px #2ecc71;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand shine-effect" href="index.php">
                <strong>Savion Sports Club</strong>
            </a>
            
            <!-- Added images in the center of navbar -->
            <div class="mx-auto d-none d-lg-block d-flex align-items-center">
                <!-- Left image -->
                <img src="images/1.jpg" alt="Image 1" class="img-fluid rounded-circle mx-2 navbar-img" style="height: 50px; width: 50px; object-fit: cover;">
                
                <!-- Center image (swami.jpg) -->
                <img src="images/swami.jpg" alt="Swami" class="img-fluid rounded-circle mx-2 navbar-img pulse" style="height: 50px; width: 50px; object-fit: cover;">
                
                <!-- Right image -->
                <img src="images/2.jpg" alt="Image 2" class="img-fluid rounded-circle mx-2 navbar-img" style="height: 50px; width: 50px; object-fit: cover;">
            </div>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">Home</a>
                    </li>
                    <?php if (is_logged_in()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo has_role('admin') ? 'admin/dashboard.php' : 'user/dashboard.php'; ?>">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="register.php">Register</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-8 offset-md-2 text-center content-wrapper animate__animated animate__fadeIn" data-aos="fade-up">
                <h1 class="display-4 animate__animated animate__fadeInDown" style="font-family: 'Montserrat', sans-serif; font-weight: 900; text-shadow: 3px 3px 6px rgba(0,0,0,0.15); letter-spacing: 3px; background: linear-gradient(to right, #1a5276, #3498db, #2ecc71); -webkit-background-clip: text; background-clip: text; color: transparent;">
                    <span class="animate__animated animate__fadeInLeft animate__delay-1s" style="font-style: italic; color: #1a5276;">Welcome</span> 
                    <span class="animate__animated animate__fadeInRight animate__delay-1s" style="font-size: 0.8em; color: #3498db;">to</span> 
                    <span class="animate__animated animate__bounceIn animate__delay-2s gradient-text" style="font-size: 1.2em; font-weight: 900; text-shadow: 2px 2px 4px rgba(46, 204, 113, 0.3);">Savion</span> 
                    <span class="rainbow-text" style="font-family: 'Poppins', sans-serif; font-weight: 800; text-shadow: 1px 1px 3px rgba(0,0,0,0.2);">Sports Club</span>
                </h1>
                <p class="lead animate__animated animate__fadeInUp animate__delay-1s glow" style="font-family: 'Montserrat', sans-serif; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; margin-top: 15px; background: linear-gradient(45deg, #9b59b6, #3498db, #2ecc71); -webkit-background-clip: text; background-clip: text; color: transparent;">Inventory Management System</p>
                <hr class="my-4 animate__animated animate__zoomIn animate__delay-2s" style="width: 70%; margin: 2rem auto; border-width: 3px; background: var(--gradient-1); border-radius: 5px; height: 6px;">
                <p class="animate__animated animate__fadeIn animate__delay-2s" style="font-size: 1.2rem; color: #34495e; font-family: 'Poppins', sans-serif; font-weight: 400; line-height: 1.8; margin: 0 auto; max-width: 85%; text-shadow: 0px 0px 1px rgba(0,0,0,0.1);">Track and manage sports equipment efficiently with our inventory management system.</p>
                
                <?php if (!is_logged_in()): ?>
                    <div class="mt-5 animate__animated animate__fadeInUp animate__delay-3s">
                        <a href="login.php" class="btn btn-primary me-3 shine-effect" style="font-weight: 700; text-transform: uppercase; letter-spacing: 2px; padding: 12px 30px; font-size: 1.1rem; background-image: linear-gradient(135deg, #3498db, #2ecc71); border: none;">Login</a>
                        <a href="register.php" class="btn btn-outline-primary shine-effect" style="font-weight: 700; text-transform: uppercase; letter-spacing: 2px; padding: 12px 30px; font-size: 1.1rem; border: 2px solid #3498db; color: #3498db;">Register</a>
                    </div>
                <?php else: ?>
                    <div class="mt-5 animate__animated animate__fadeInUp animate__delay-3s">
                        <a href="<?php echo has_role('admin') ? 'admin/dashboard.php' : 'user/dashboard.php'; ?>" class="btn btn-primary shine-effect" style="font-weight: 700; text-transform: uppercase; letter-spacing: 2px; padding: 12px 30px; font-size: 1.1rem; background-image: linear-gradient(135deg, #3498db, #2ecc71); border: none;">Go to Dashboard</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-4" data-aos="fade-right" data-aos-delay="100">
                <div class="card h-100 floating">
                    <div class="card-body text-center">
                        <i class="fas fa-users fa-3x mb-3 text-primary animate__animated animate__heartBeat animate__delay-2s rotate-icon"></i>
                        <h3 class="animate__animated animate__fadeIn animate__delay-3s">Role-Based Access</h3>
                        <p class="animate__animated animate__fadeIn animate__delay-3s">Different access levels for administrators, coaches, and players.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
                <div class="card h-100 floating" style="animation-delay: 0.5s">
                    <div class="card-body text-center">
                        <i class="fas fa-clipboard-list fa-3x mb-3 text-primary animate__animated animate__heartBeat animate__delay-3s rotate-icon"></i>
                        <h3 class="animate__animated animate__fadeIn animate__delay-4s">Equipment Tracking</h3>
                        <p class="animate__animated animate__fadeIn animate__delay-4s">Keep track of all sports equipment with quantity, status, and location.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4" data-aos="fade-left" data-aos-delay="300">
                <div class="card h-100 floating" style="animation-delay: 1s">
                    <div class="card-body text-center">
                        <i class="fas fa-bell fa-3x mb-3 text-primary animate__animated animate__heartBeat animate__delay-4s rotate-icon"></i>
                        <h3 class="animate__animated animate__fadeIn animate__delay-5s">Notifications</h3>
                        <p class="animate__animated animate__fadeIn animate__delay-5s">Get notified about overdue returns and low stock items.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="mt-5 py-4 bg-dark text-white">
        <div class="container text-center animate__animated animate__fadeIn">
            <p>&copy; <?php echo date('Y'); ?> Savion Sports Club. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        // Initialize AOS (Animate On Scroll)
        AOS.init({
            duration: 800,
            easing: 'ease-out-cubic',
            once: false,
            mirror: true
        });
        
        // Add smooth scrolling
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
        
        // Navbar animation on scroll
        window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 50) {
                navbar.style.padding = '10px 0';
                navbar.style.backgroundColor = 'rgba(52, 152, 219, 0.95)';
                navbar.style.boxShadow = '0 5px 20px rgba(0, 0, 0, 0.1)';
            } else {
                navbar.style.padding = '20px 0';
                navbar.style.backgroundColor = '#3498db';
                navbar.style.boxShadow = 'none';
            }
        });
        
        // Add animation to navbar images
        const navbarImages = document.querySelectorAll('.navbar img');
        navbarImages.forEach(img => {
            img.classList.add('navbar-img');
        });
        
        // Add random animation delays to elements
        document.querySelectorAll('.floating').forEach((el, index) => {
            el.style.animationDelay = (index * 0.2) + 's';
        });
        
        // Create a more dynamic experience with cursor effects
        document.addEventListener('mousemove', function(e) {
            const cards = document.querySelectorAll('.card');
            cards.forEach(card => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                if (x > 0 && x < rect.width && y > 0 && y < rect.height) {
                    const xPercent = ((x / rect.width) - 0.5) * 10;
                    const yPercent = ((y / rect.height) - 0.5) * 10;
                    card.style.transform = `perspective(1000px) rotateY(${xPercent}deg) rotateX(${-yPercent}deg) translateZ(10px)`;
                } else {
                    card.style.transform = 'perspective(1000px) rotateY(0) rotateX(0) translateZ(0)';
                }
            });
        });
    </script>
</body>
</html>