<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('../login.php');
}

// Check if user is coach
if (!has_role('coach')) {
    set_message('error', 'You do not have permission to access this page.');
    redirect('dashboard.php');
}

// Check if request ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    set_message('error', 'Invalid request ID.');
    redirect('coach_requests.php');
}

$request_id = sanitize_input($_GET['id']);

// Get request details
$request = get_request_by_id($request_id);

// Check if request exists and is approved
if (!$request || $request['status'] != 'approved' || !empty($request['actual_return_date'])) {
    set_message('error', 'Invalid request or equipment already returned.');
    redirect('coach_requests.php');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $condition = sanitize_input($_POST['condition']);
    $notes = sanitize_input($_POST['notes']);
    
    // Update request status to returned
    $sql = "UPDATE equipment_requests SET 
            status = 'returned', 
            actual_return_date = NOW(),
            return_condition = ?,
            return_notes = ?
            WHERE id = ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssi", $condition, $notes, $request_id);
    
    if (mysqli_stmt_execute($stmt)) {
        // Update equipment available quantity
        $equipment = get_equipment_by_id($request['equipment_id']);
        $new_available = $equipment['available'] + $request['quantity'];
        
        $sql = "UPDATE equipment SET available = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ii", $new_available, $request['equipment_id']);
        mysqli_stmt_execute($stmt);
        
        // Create notification for the user
        $message = "Your " . $request['equipment_name'] . " has been marked as returned.";
        $link = "request_details.php?id=" . $request_id;
        create_notification($request['user_id'], 'request_update', $message, $link);
        
        set_message('success', 'Equipment has been marked as returned successfully.');
        redirect('coach_requests.php');
    } else {
        set_message('error', 'Failed to mark equipment as returned. Please try again.');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark as Returned - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include_once 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Mark Equipment as Returned</h5>
                    </div>
                    <div class="card-body">
                        <?php echo display_messages(); ?>
                        
                        <div class="alert alert-info">
                            <p><strong>Student:</strong> <?php echo htmlspecialchars($request['full_name'] ?: $request['username']); ?></p>
                            <p><strong>Equipment:</strong> <?php echo htmlspecialchars($request['equipment_name']); ?></p>
                            <p><strong>Quantity:</strong> <?php echo $request['quantity']; ?></p>
                            <p><strong>Checkout Date:</strong> <?php echo date('M d, Y', strtotime($request['approval_date'])); ?></p>
                            <p><strong>Expected Return:</strong> <?php echo date('M d, Y', strtotime($request['expected_return_date'])); ?></p>
                        </div>
                        
                        <form method="post" action="">
                            <div class="mb-3">
                                <label for="condition" class="form-label">Return Condition</label>
                                <select class="form-select" id="condition" name="condition" required>
                                    <option value="">Select condition...</option>
                                    <option value="excellent">Excellent - Like new</option>
                                    <option value="good">Good - Minor wear</option>
                                    <option value="fair">Fair - Noticeable wear but functional</option>
                                    <option value="poor">Poor - Damaged or not fully functional</option>
                                    <option value="damaged">Damaged - Needs repair</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="notes" class="form-label">Notes (Optional)</label>
                                <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                                <div class="form-text">Add any notes about the condition or issues with the returned equipment.</div>
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <a href="coach_request_details.php?id=<?php echo $request_id; ?>" class="btn btn-secondary">Cancel</a>
                                <button type="submit" class="btn btn-primary">Mark as Returned</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>