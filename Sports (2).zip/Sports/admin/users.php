<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and is an admin
if (!is_logged_in() || !has_role('admin')) {
    redirect('../login.php?error=unauthorized');
}

// Handle user actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $user_id = $_GET['id'];
    
    if ($action === 'delete' && $user_id != (isset($_SESSION['id']) ? $_SESSION['id'] : 0)) {
        // Delete user
        $sql = "DELETE FROM users WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        if (mysqli_stmt_execute($stmt)) {
            redirect('users.php?success=user_deleted');
        } else {
            redirect('users.php?error=delete_failed');
        }
    } elseif ($action === 'toggle_status') {
        // Toggle user active status
        $user = get_user($user_id);
        $new_status = isset($user['active']) && $user['active'] ? 0 : 1;
        
        $sql = "UPDATE users SET active = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ii", $new_status, $user_id);
        if (mysqli_stmt_execute($stmt)) {
            redirect('users.php?success=status_updated');
        } else {
            redirect('users.php?error=update_failed');
        }
    } elseif ($action === 'change_role') {
        // Change user role
        $user = get_user($user_id);
        $new_role = $user['role'] === 'admin' ? 'user' : 'admin';
        
        $sql = "UPDATE users SET role = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "si", $new_role, $user_id);
        if (mysqli_stmt_execute($stmt)) {
            redirect('users.php?success=role_updated');
        } else {
            redirect('users.php?error=update_failed');
        }
    }
}

// Get all users
$sql = "SELECT * FROM users ORDER BY username ASC";
$result = mysqli_query($conn, $sql);
$users = [];
while ($row = mysqli_fetch_assoc($result)) {
    $users[] = $row;
}

// Page title
// After setting the page title but before including the header
$page_title = "User Management"; // This line might be different in your file
?>

<!-- Add custom styles for background image -->
<style>
    body {
        position: relative;
        background-color: transparent !important;
    }
    
    body::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: url('../images/sgbit.jpg');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        opacity: 0.2;
        z-index: -1;
    }
</style>

<?php
include_once '../includes/header.php';
?>

<style>
    /* Custom styles for users page */
    .user-card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .user-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    }
    
    .table-hover tbody tr:hover {
        background-color: rgba(0, 123, 255, 0.05);
    }
    
    .action-buttons .btn {
        margin-right: 5px;
        border-radius: 50%;
        width: 32px;
        height: 32px;
        padding: 0;
        line-height: 32px;
        text-align: center;
    }
    
    .action-buttons .btn i {
        font-size: 14px;
    }
    
    .search-container {
        position: relative;
    }
    
    .search-container .fa-search {
        position: absolute;
        top: 12px;
        left: 12px;
        color: #6c757d;
    }
    
    .search-input {
        padding-left: 35px;
        border-radius: 20px;
    }
    
    .badge {
        font-size: 85%;
        font-weight: 500;
        padding: 0.35em 0.65em;
    }
    
    .table th {
        background-color: #f8f9fa;
        border-top: none;
    }
    
    .page-header {
        border-bottom: 1px solid #e3e6f0;
        padding-bottom: 1rem;
        margin-bottom: 1.5rem;
    }
    
    .btn-add-user {
        border-radius: 50px;
        padding: 0.375rem 1.2rem;
        font-weight: 500;
    }
    
    .alert {
        border-radius: 10px;
        border-left: 4px solid;
    }
    
    .alert-success {
        border-left-color: #28a745;
    }
    
    .alert-danger {
        border-left-color: #dc3545;
    }
</style>

<div class="container-fluid py-4">
    <div class="row mb-4 page-header">
        <div class="col">
            <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-users me-2"></i> Manage Users</h1>
        </div>
        <div class="col-auto">
            <a href="add_user.php" class="btn btn-primary btn-add-user">
                <i class="fas fa-user-plus me-2"></i> Add New User
            </a>
        </div>
    </div>
    
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <?php 
                $success = $_GET['success'];
                if ($success === 'user_deleted') {
                    echo "User has been deleted successfully.";
                } elseif ($success === 'status_updated') {
                    echo "User status has been updated successfully.";
                } elseif ($success === 'role_updated') {
                    echo "User role has been updated successfully.";
                } elseif ($success === 'user_added') {
                    echo "New user has been added successfully.";
                } elseif ($success === 'user_updated') {
                    echo "User has been updated successfully.";
                }
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?php 
                $error = $_GET['error'];
                if ($error === 'delete_failed') {
                    echo "Failed to delete user. Please try again.";
                } elseif ($error === 'update_failed') {
                    echo "Failed to update user. Please try again.";
                }
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <div class="card shadow mb-4 user-card">
        <div class="card-header py-3 d-flex justify-content-between align-items-center bg-light">
            <h6 class="m-0 font-weight-bold text-primary">All Users</h6>
            <div class="search-container" style="width: 300px;">
                <i class="fas fa-search"></i>
                <input type="text" id="userSearch" class="form-control search-input" placeholder="Search users...">
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="usersTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Full Name</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Registered</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo $user['id']; ?></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="avatar bg-light text-primary rounded-circle me-2 d-flex align-items-center justify-content-center" style="width: 35px; height: 35px;">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <span><?php echo htmlspecialchars($user['username']); ?></span>
                                </div>
                            </td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <?php 
                                    $first_name = isset($user['first_name']) ? $user['first_name'] : '';
                                    $last_name = isset($user['last_name']) ? $user['last_name'] : '';
                                    $fullname = trim($first_name . ' ' . $last_name);
                                    echo !empty($fullname) ? htmlspecialchars($fullname) : '<em class="text-muted">Not provided</em>';
                                ?>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo $user['role'] === 'admin' ? 'danger' : ($user['role'] === 'coach' ? 'warning' : 'primary'); ?> rounded-pill">
                                    <?php echo ucfirst($user['role']); ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo isset($user['active']) && $user['active'] ? 'success' : 'secondary'; ?> rounded-pill">
                                    <?php echo isset($user['active']) && $user['active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td><?php echo isset($user['created_at']) ? date('M d, Y', strtotime($user['created_at'])) : 'N/A'; ?></td>
                            <td>
                                <div class="action-buttons d-flex justify-content-center">
                                    <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="Edit User">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <?php if ($user['id'] != (isset($_SESSION['id']) ? $_SESSION['id'] : 0)): ?>
                                        <a href="users.php?action=toggle_status&id=<?php echo $user['id']; ?>" class="btn btn-sm btn-<?php echo isset($user['active']) && $user['active'] ? 'warning' : 'success'; ?>" data-bs-toggle="tooltip" title="<?php echo isset($user['active']) && $user['active'] ? 'Deactivate' : 'Activate'; ?> User">
                                            <i class="fas fa-<?php echo isset($user['active']) && $user['active'] ? 'user-slash' : 'user-check'; ?>"></i>
                                        </a>
                                        <a href="users.php?action=change_role&id=<?php echo $user['id']; ?>" class="btn btn-sm btn-info" data-bs-toggle="tooltip" title="Change Role">
                                            <i class="fas fa-exchange-alt"></i>
                                        </a>
                                        <a href="#" class="btn btn-sm btn-danger delete-user" data-id="<?php echo $user['id']; ?>" data-username="<?php echo htmlspecialchars($user['username']); ?>" data-bs-toggle="tooltip" title="Delete User">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Delete User Modal -->
<div class="modal fade" id="deleteUserModal" tabindex="-1" aria-labelledby="deleteUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="deleteUserModalLabel">
                    <i class="fas fa-exclamation-triangle me-2"></i> Confirm Delete
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the user <strong id="deleteUserName"></strong>?</p>
                <p class="text-danger"><i class="fas fa-exclamation-circle me-2"></i> This action cannot be undone and will remove all data associated with this user.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="fas fa-times me-2"></i> Cancel
                </button>
                <a href="#" id="confirmDeleteUser" class="btn btn-danger">
                    <i class="fas fa-trash-alt me-2"></i> Delete User
                </a>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Handle delete user confirmation
    const deleteButtons = document.querySelectorAll('.delete-user');
    const deleteUserName = document.getElementById('deleteUserName');
    const confirmDeleteUser = document.getElementById('confirmDeleteUser');
    
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const userId = this.getAttribute('data-id');
            const username = this.getAttribute('data-username');
            
            deleteUserName.textContent = username;
            confirmDeleteUser.href = `users.php?action=delete&id=${userId}`;
            
            const deleteModal = new bootstrap.Modal(document.getElementById('deleteUserModal'));
            deleteModal.show();
        });
    });
    
    // Search functionality
    const userSearch = document.getElementById('userSearch');
    userSearch.addEventListener('keyup', function() {
        const searchValue = this.value.toLowerCase();
        const table = document.getElementById('usersTable');
        const rows = table.getElementsByTagName('tr');
        
        for (let i = 1; i < rows.length; i++) {
            const row = rows[i];
            const cells = row.getElementsByTagName('td');
            let found = false;
            
            for (let j = 0; j < cells.length - 1; j++) {
                const cellText = cells[j].textContent.toLowerCase();
                if (cellText.indexOf(searchValue) > -1) {
                    found = true;
                    break;
                }
            }
            
            row.style.display = found ? '' : 'none';
        }
    });
});
</script>

<?php include_once 'includes/footer.php'; ?>