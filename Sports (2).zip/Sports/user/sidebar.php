<div class="list-group mb-4">
    <a href="dashboard.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
        <i class="fas fa-tachometer-alt me-2"></i> Dashboard
    </a>
    <a href="equipment.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'equipment.php' ? 'active' : ''; ?>">
        <i class="fas fa-dumbbell me-2"></i> Equipment
    </a>
    <a href="requests.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'requests.php' ? 'active' : ''; ?>">
        <i class="fas fa-clipboard-list me-2"></i> My Requests
    </a>
    <a href="profile.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>">
        <i class="fas fa-user me-2"></i> My Profile
    </a>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Quick Links</h5>
    </div>
    <div class="card-body">
        <a href="equipment.php?action=request" class="btn btn-primary btn-sm d-block mb-2">
            <i class="fas fa-plus-circle me-2"></i> New Request
        </a>
        <a href="../logout.php" class="btn btn-danger btn-sm d-block">
            <i class="fas fa-sign-out-alt me-2"></i> Logout
        </a>
    </div>
</div>